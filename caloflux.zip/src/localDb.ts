export interface FoodItem {
  name: string;
  calories: number;
  protein: number; // in g
  carbs: number;   // in g
  fat: number;     // in g
  fiber: number;   // in g
  sugar: number;   // in g
  sodium: number;  // in mg
  serving: string;
}

export const FOOD_LABELS = [
  "pizza", "burger", "sandwich", "salad", "soup", "sushi", "steak", "chicken",
  "salmon", "egg", "bread", "pasta", "rice", "noodle", "pancake", "waffle",
  "donut", "cake", "cookie", "ice cream", "fruit", "banana", "apple", "orange",
  "broccoli", "carrot", "corn", "mushroom", "potato", "french fries", "coffee",
  "juice", "milk", "yogurt", "cheese", "bacon", "shrimp", "taco", "burrito",
  "hotdog", "pretzel", "bagel", "muffin", "chocolate", "strawberry", "pineapple",
  "avocado", "guacamole", "hummus", "oatmeal", "cereal", "granola", "smoothie"
];

export const localFoodDb: FoodItem[] = [
  // Fruits (30 items)
  { name: "Apple", calories: 52, protein: 0.3, carbs: 13.8, fat: 0.2, fiber: 2.4, sugar: 10.4, sodium: 1, serving: "100g" },
  { name: "Banana", calories: 89, protein: 1.1, carbs: 22.8, fat: 0.3, fiber: 2.6, sugar: 12.2, sodium: 1, serving: "100g" },
  { name: "Orange", calories: 47, protein: 0.9, carbs: 11.8, fat: 0.1, fiber: 2.4, sugar: 9.4, sodium: 0, serving: "100g" },
  { name: "Strawberry", calories: 32, protein: 0.7, carbs: 7.7, fat: 0.3, fiber: 2.0, sugar: 4.9, sodium: 1, serving: "100g" },
  { name: "Blueberry", calories: 57, protein: 0.7, carbs: 14.5, fat: 0.3, fiber: 2.4, sugar: 10.0, sodium: 1, serving: "100g" },
  { name: "Grape", calories: 69, protein: 0.7, carbs: 18.1, fat: 0.2, fiber: 0.9, sugar: 15.5, sodium: 2, serving: "100g" },
  { name: "Mango", calories: 60, protein: 0.8, carbs: 15.0, fat: 0.4, fiber: 1.6, sugar: 13.7, sodium: 1, serving: "100g" },
  { name: "Pineapple", calories: 50, protein: 0.5, carbs: 13.1, fat: 0.1, fiber: 1.4, sugar: 9.9, sodium: 1, serving: "100g" },
  { name: "Watermelon", calories: 30, protein: 0.6, carbs: 7.6, fat: 0.2, fiber: 0.4, sugar: 6.2, sodium: 1, serving: "100g" },
  { name: "Peach", calories: 39, protein: 0.9, carbs: 9.5, fat: 0.3, fiber: 1.5, sugar: 8.4, sodium: 0, serving: "100g" },
  { name: "Pear", calories: 57, protein: 0.4, carbs: 15.2, fat: 0.1, fiber: 3.1, sugar: 9.8, sodium: 1, serving: "100g" },
  { name: "Cherry", calories: 50, protein: 1.0, carbs: 12.2, fat: 0.3, fiber: 1.6, sugar: 8.5, sodium: 0, serving: "100g" },
  { name: "Kiwi", calories: 61, protein: 1.1, carbs: 14.7, fat: 0.5, fiber: 3.0, sugar: 9.0, sodium: 3, serving: "100g" },
  { name: "Raspberry", calories: 52, protein: 1.2, carbs: 11.9, fat: 0.7, fiber: 6.5, sugar: 4.4, sodium: 1, serving: "100g" },
  { name: "Blackberry", calories: 43, protein: 1.4, carbs: 9.6, fat: 0.5, fiber: 5.3, sugar: 4.9, sodium: 1, serving: "100g" },
  { name: "Avocado", calories: 160, protein: 2.0, carbs: 8.5, fat: 14.7, fiber: 6.7, sugar: 0.7, sodium: 7, serving: "100g" },
  { name: "Lemon", calories: 29, protein: 1.1, carbs: 9.3, fat: 0.3, fiber: 2.8, sugar: 2.5, sodium: 2, serving: "100g" },
  { name: "Lime", calories: 30, protein: 0.7, carbs: 10.5, fat: 0.2, fiber: 2.8, sugar: 1.7, sodium: 2, serving: "100g" },
  { name: "Grapefruit", calories: 42, protein: 0.8, carbs: 10.7, fat: 0.1, fiber: 1.6, sugar: 6.9, sodium: 0, serving: "100g" },
  { name: "Plum", calories: 46, protein: 0.7, carbs: 11.4, fat: 0.3, fiber: 1.4, sugar: 9.9, sodium: 0, serving: "100g" },
  { name: "Nectarine", calories: 44, protein: 1.1, carbs: 10.6, fat: 0.3, fiber: 1.7, sugar: 7.9, sodium: 0, serving: "100g" },
  { name: "Apricot", calories: 48, protein: 1.4, carbs: 11.1, fat: 0.4, fiber: 2.0, sugar: 9.2, sodium: 1, serving: "100g" },
  { name: "Fig", calories: 74, protein: 0.8, carbs: 19.2, fat: 0.3, fiber: 2.9, sugar: 16.3, sodium: 1, serving: "100g" },
  { name: "Date", calories: 282, protein: 2.5, carbs: 75.0, fat: 0.4, fiber: 8.0, sugar: 63.4, sodium: 2, serving: "100g" },
  { name: "Raisin", calories: 299, protein: 3.1, carbs: 79.2, fat: 0.5, fiber: 3.7, sugar: 59.2, sodium: 11, serving: "100g" },
  { name: "Cranberry", calories: 46, protein: 0.4, carbs: 12.2, fat: 0.1, fiber: 4.6, sugar: 4.0, sodium: 2, serving: "100g" },
  { name: "Pomegranate", calories: 83, protein: 1.7, carbs: 18.7, fat: 1.2, fiber: 4.0, sugar: 13.7, sodium: 3, serving: "100g" },
  { name: "Cantaloupe", calories: 34, protein: 0.8, carbs: 8.2, fat: 0.2, fiber: 0.9, sugar: 7.9, sodium: 16, serving: "100g" },
  { name: "Honeydew", calories: 36, protein: 0.5, carbs: 9.1, fat: 0.1, fiber: 0.8, sugar: 8.1, sodium: 18, serving: "100g" },

  // Vegetables (30 items)
  { name: "Broccoli", calories: 34, protein: 2.8, carbs: 6.6, fat: 0.4, fiber: 2.6, sugar: 1.7, sodium: 33, serving: "100g" },
  { name: "Spinach", calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4, fiber: 2.2, sugar: 0.4, sodium: 79, serving: "100g" },
  { name: "Brussels Sprouts", calories: 43, protein: 3.4, carbs: 9.0, fat: 0.3, fiber: 3.8, sugar: 2.2, sodium: 25, serving: "100g" },
  { name: "Asparagus", calories: 20, protein: 2.2, carbs: 3.9, fat: 0.1, fiber: 2.1, sugar: 1.9, sodium: 2, serving: "100g" },
  { name: "Green Beans", calories: 31, protein: 1.8, carbs: 7.0, fat: 0.2, fiber: 2.7, sugar: 3.3, sodium: 6, serving: "100g" },
  { name: "Peas", calories: 81, protein: 5.4, carbs: 14.5, fat: 0.4, fiber: 5.1, sugar: 5.7, sodium: 5, serving: "100g" },
  { name: "Sweet Corn", calories: 86, protein: 3.2, carbs: 19.0, fat: 1.2, fiber: 2.7, sugar: 6.3, sodium: 15, serving: "100g" },
  { name: "Potato", calories: 77, protein: 2.0, carbs: 17.0, fat: 0.1, fiber: 2.2, sugar: 0.8, sodium: 6, serving: "100g" },
  { name: "Sweet Potato", calories: 86, protein: 1.6, carbs: 20.0, fat: 0.1, fiber: 3.0, sugar: 4.2, sodium: 55, serving: "100g" },
  { name: "Carrot", calories: 41, protein: 0.9, carbs: 9.6, fat: 0.2, fiber: 2.8, sugar: 4.7, sodium: 69, serving: "100g" },
  { name: "Tomato", calories: 18, protein: 0.9, carbs: 3.9, fat: 0.2, fiber: 1.2, sugar: 2.6, sodium: 5, serving: "100g" },
  { name: "Cucumber", calories: 15, protein: 0.7, carbs: 3.6, fat: 0.1, fiber: 0.5, sugar: 1.7, sodium: 2, serving: "100g" },
  { name: "Zucchini", calories: 17, protein: 1.2, carbs: 3.1, fat: 0.3, fiber: 1.0, sugar: 2.5, sodium: 8, serving: "100g" },
  { name: "Eggplant", calories: 25, protein: 1.0, carbs: 6.0, fat: 0.2, fiber: 3.0, sugar: 3.5, sodium: 2, serving: "100g" },
  { name: "Onion", calories: 40, protein: 1.1, carbs: 9.3, fat: 0.1, fiber: 1.7, sugar: 4.2, sodium: 4, serving: "100g" },
  { name: "Garlic", calories: 149, protein: 6.4, carbs: 33.1, fat: 0.5, fiber: 2.1, sugar: 1.0, sodium: 17, serving: "100g" },
  { name: "Bell Pepper", calories: 20, protein: 0.9, carbs: 4.6, fat: 0.2, fiber: 1.7, sugar: 2.4, sodium: 4, serving: "100g" },
  { name: "Mushrooms", calories: 22, protein: 3.1, carbs: 3.3, fat: 0.3, fiber: 1.0, sugar: 2.0, sodium: 5, serving: "100g" },
  { name: "Cauliflower", calories: 25, protein: 1.9, carbs: 5.0, fat: 0.3, fiber: 2.0, sugar: 1.9, sodium: 30, serving: "100g" },
  { name: "Celery", calories: 16, protein: 0.7, carbs: 3.0, fat: 0.2, fiber: 1.6, sugar: 1.3, sodium: 80, serving: "100g" },
  { name: "Lettuce", calories: 15, protein: 1.4, carbs: 2.9, fat: 0.2, fiber: 1.3, sugar: 0.8, sodium: 28, serving: "100g" },
  { name: "Cabbage", calories: 25, protein: 1.3, carbs: 5.8, fat: 0.1, fiber: 2.5, sugar: 3.2, sodium: 18, serving: "100g" },
  { name: "Kale", calories: 49, protein: 4.3, carbs: 8.8, fat: 0.9, fiber: 3.6, sugar: 2.3, sodium: 38, serving: "100g" },
  { name: "Radish", calories: 16, protein: 0.7, carbs: 3.4, fat: 0.1, fiber: 1.6, sugar: 1.9, sodium: 39, serving: "100g" },
  { name: "Beetroot", calories: 43, protein: 1.6, carbs: 10.0, fat: 0.2, fiber: 2.8, sugar: 6.8, sodium: 78, serving: "100g" },
  { name: "Pumpkin", calories: 26, protein: 1.0, carbs: 6.5, fat: 0.1, fiber: 0.5, sugar: 2.8, sodium: 1, serving: "100g" },
  { name: "Squash", calories: 16, protein: 1.2, carbs: 3.4, fat: 0.2, fiber: 1.1, sugar: 2.2, sodium: 2, serving: "100g" },
  { name: "Artichoke", calories: 47, protein: 3.3, carbs: 10.5, fat: 0.2, fiber: 5.4, sugar: 1.0, sodium: 94, serving: "100g" },
  { name: "Turnip", calories: 28, protein: 0.9, carbs: 6.4, fat: 0.1, fiber: 1.8, sugar: 3.8, sodium: 67, serving: "100g" },
  { name: "Asparagus Green", calories: 20, protein: 2.2, carbs: 3.9, fat: 0.1, fiber: 2.1, sugar: 1.9, sodium: 2, serving: "100g" },

  // Proteins & Meats (30 items)
  { name: "Chicken Breast", calories: 165, protein: 31.0, carbs: 0.0, fat: 3.6, fiber: 0.0, sugar: 0.0, sodium: 74, serving: "100g" },
  { name: "Chicken Thigh", calories: 209, protein: 26.0, carbs: 0.0, fat: 10.9, fiber: 0.0, sugar: 0.0, sodium: 87, serving: "100g" },
  { name: "Beef Sirloin", calories: 244, protein: 27.0, carbs: 0.0, fat: 15.0, fiber: 0.0, sugar: 0.0, sodium: 54, serving: "100g" },
  { name: "Ground Beef 93/7", calories: 172, protein: 21.4, carbs: 0.0, fat: 9.0, fiber: 0.0, sugar: 0.0, sodium: 66, serving: "100g" },
  { name: "Ground Beef 80/20", calories: 254, protein: 17.2, carbs: 0.0, fat: 20.0, fiber: 0.0, sugar: 0.0, sodium: 72, serving: "100g" },
  { name: "Pork Chop", calories: 231, protein: 26.2, carbs: 0.0, fat: 14.3, fiber: 0.0, sugar: 0.0, sodium: 50, serving: "100g" },
  { name: "Bacon", calories: 541, protein: 37.0, carbs: 1.4, fat: 42.0, fiber: 0.0, sugar: 0.0, sodium: 1720, serving: "100g" },
  { name: "Turkey Breast", calories: 135, protein: 30.1, carbs: 0.0, fat: 0.7, fiber: 0.0, sugar: 0.0, sodium: 49, serving: "100g" },
  { name: "Lamb Chop", calories: 294, protein: 25.0, carbs: 0.0, fat: 21.0, fiber: 0.0, sugar: 0.0, sodium: 72, serving: "100g" },
  { name: "Salmon", calories: 208, protein: 20.0, carbs: 0.0, fat: 13.0, fiber: 0.0, sugar: 0.0, sodium: 59, serving: "100g" },
  { name: "Tuna (canned)", calories: 116, protein: 26.0, carbs: 0.0, fat: 1.0, fiber: 0.0, sugar: 0.0, sodium: 338, serving: "100g" },
  { name: "Cod", calories: 82, protein: 18.0, carbs: 0.0, fat: 0.7, fiber: 0.0, sugar: 0.0, sodium: 54, serving: "100g" },
  { name: "Shrimp", calories: 85, protein: 20.0, carbs: 0.0, fat: 0.5, fiber: 0.0, sugar: 0.0, sodium: 111, serving: "100g" },
  { name: "Crab", calories: 83, protein: 18.1, carbs: 0.0, fat: 1.0, fiber: 0.0, sugar: 0.0, sodium: 293, serving: "100g" },
  { name: "Lobster", calories: 89, protein: 19.0, carbs: 0.0, fat: 0.9, fiber: 0.0, sugar: 0.0, sodium: 380, serving: "100g" },
  { name: "Trout", calories: 141, protein: 20.0, carbs: 0.0, fat: 6.0, fiber: 0.0, sugar: 0.0, sodium: 51, serving: "100g" },
  { name: "Sardines", calories: 208, protein: 25.0, carbs: 0.0, fat: 11.0, fiber: 0.0, sugar: 0.0, sodium: 505, serving: "100g" },
  { name: "Scallops", calories: 111, protein: 20.5, carbs: 5.4, fat: 0.8, fiber: 0.0, sugar: 0.0, sodium: 660, serving: "100g" },
  { name: "Oyster", calories: 81, protein: 9.0, carbs: 5.0, fat: 2.5, fiber: 0.0, sugar: 0.0, sodium: 106, serving: "100g" },
  { name: "Duck Breast", calories: 140, protein: 19.0, carbs: 0.0, fat: 6.0, fiber: 0.0, sugar: 0.0, sodium: 65, serving: "100g" },
  { name: "Pork Loin", calories: 143, protein: 26.0, carbs: 0.0, fat: 3.5, fiber: 0.0, sugar: 0.0, sodium: 48, serving: "100g" },
  { name: "Ham", calories: 145, protein: 21.0, carbs: 1.5, fat: 6.0, fiber: 0.0, sugar: 1.0, sodium: 1150, serving: "100g" },
  { name: "Venison", calories: 158, protein: 30.0, carbs: 0.0, fat: 3.2, fiber: 0.0, sugar: 0.0, sodium: 54, serving: "100g" },
  { name: "Turkey Ground", calories: 148, protein: 20.1, carbs: 0.0, fat: 7.4, fiber: 0.0, sugar: 0.0, sodium: 81, serving: "100g" },
  { name: "Chicken Wing", calories: 203, protein: 22.0, carbs: 0.0, fat: 12.0, fiber: 0.0, sugar: 0.0, sodium: 82, serving: "100g" },
  { name: "Salami", calories: 425, protein: 22.0, carbs: 1.2, fat: 37.0, fiber: 0.0, sugar: 1.0, sodium: 1890, serving: "100g" },
  { name: "Prosciutto", calories: 270, protein: 26.0, carbs: 0.3, fat: 18.0, fiber: 0.0, sugar: 0.0, sodium: 2000, serving: "100g" },
  { name: "Beef Jerky", calories: 410, protein: 33.0, carbs: 11.0, fat: 25.0, fiber: 1.8, sugar: 9.0, sodium: 2080, serving: "100g" },
  { name: "Pork Sausage", calories: 339, protein: 15.0, carbs: 1.0, fat: 31.0, fiber: 0.0, sugar: 0.5, sodium: 840, serving: "100g" },
  { name: "Duck Leg", calories: 217, protein: 17.0, carbs: 0.0, fat: 16.0, fiber: 0.0, sugar: 0.0, sodium: 76, serving: "100g" },

  // Dairy & Eggs (25 items)
  { name: "Eggs (whole)", calories: 155, protein: 13.0, carbs: 1.1, fat: 11.0, fiber: 0.0, sugar: 1.1, sodium: 124, serving: "100g" },
  { name: "Egg Whites", calories: 52, protein: 11.0, carbs: 0.7, fat: 0.2, fiber: 0.0, sugar: 0.7, sodium: 166, serving: "100g" },
  { name: "Greek Yogurt 0%", calories: 59, protein: 10.0, carbs: 3.6, fat: 0.4, fiber: 0.0, sugar: 3.2, sodium: 36, serving: "100g" },
  { name: "Greek Yogurt", calories: 97, protein: 9.0, carbs: 4.0, fat: 5.0, fiber: 0.0, sugar: 3.5, sodium: 35, serving: "100g" },
  { name: "Cottage Cheese 2%", calories: 81, protein: 10.4, carbs: 4.7, fat: 2.3, fiber: 0.0, sugar: 4.0, sodium: 364, serving: "100g" },
  { name: "Cheddar Cheese", calories: 403, protein: 25.0, carbs: 1.3, fat: 33.0, fiber: 0.0, sugar: 0.5, sodium: 621, serving: "100g" },
  { name: "Mozzarella", calories: 280, protein: 22.0, carbs: 2.2, fat: 20.0, fiber: 0.0, sugar: 1.0, sodium: 500, serving: "100g" },
  { name: "Parmesan", calories: 431, protein: 38.0, carbs: 4.1, fat: 29.0, fiber: 0.0, sugar: 0.8, sodium: 1529, serving: "100g" },
  { name: "Cream Cheese", calories: 342, protein: 6.0, carbs: 4.1, fat: 34.0, fiber: 0.0, sugar: 3.2, sodium: 321, serving: "100g" },
  { name: "Swiss Cheese", calories: 380, protein: 27.0, carbs: 1.5, fat: 28.0, fiber: 0.0, sugar: 0.2, sodium: 190, serving: "100g" },
  { name: "Feta", calories: 264, protein: 14.0, carbs: 4.0, fat: 21.0, fiber: 0.0, sugar: 4.0, sodium: 917, serving: "100g" },
  { name: "Whole Milk", calories: 61, protein: 3.2, carbs: 4.8, fat: 3.3, fiber: 0.0, sugar: 5.1, sodium: 44, serving: "100g" },
  { name: "Skim Milk", calories: 34, protein: 3.4, carbs: 5.0, fat: 0.1, fiber: 0.0, sugar: 5.0, sodium: 42, serving: "100g" },
  { name: "Soy Milk", calories: 54, protein: 3.3, carbs: 6.0, fat: 1.8, fiber: 0.6, sugar: 4.0, sodium: 51, serving: "100g" },
  { name: "Almond Milk", calories: 15, protein: 0.5, carbs: 0.3, fat: 1.1, fiber: 0.2, sugar: 0.0, sodium: 70, serving: "100g" },
  { name: "Coconut Milk", calories: 230, protein: 2.3, carbs: 6.0, fat: 24.0, fiber: 2.2, sugar: 3.3, sodium: 15, serving: "100g" },
  { name: "Butter", calories: 717, protein: 0.9, carbs: 0.1, fat: 81.0, fiber: 0.0, sugar: 0.1, sodium: 11, serving: "100g" },
  { name: "Ghee", calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, fiber: 0.0, sugar: 0.0, sodium: 2, serving: "100g" },
  { name: "Sour Cream", calories: 193, protein: 2.1, carbs: 4.6, fat: 19.4, fiber: 0.0, sugar: 3.4, sodium: 50, serving: "100g" },
  { name: "Heavy Cream", calories: 340, protein: 2.8, carbs: 2.7, fat: 36.0, fiber: 0.0, sugar: 2.9, sodium: 34, serving: "100g" },
  { name: "Whey Protein", calories: 400, protein: 80.0, carbs: 6.0, fat: 6.0, fiber: 0.0, sugar: 3.0, sodium: 160, serving: "100g" },
  { name: "Kefir", calories: 64, protein: 3.5, carbs: 4.8, fat: 3.5, fiber: 0.0, sugar: 4.0, sodium: 50, serving: "100g" },
  { name: "Blue Cheese", calories: 353, protein: 21.0, carbs: 2.3, fat: 29.0, fiber: 0.0, sugar: 0.5, sodium: 1395, serving: "100g" },
  { name: "Gouda", calories: 356, protein: 25.0, carbs: 2.2, fat: 27.0, fiber: 0.0, sugar: 2.2, sodium: 819, serving: "100g" },
  { name: "Provolone", calories: 351, protein: 26.0, carbs: 2.1, fat: 27.0, fiber: 0.0, sugar: 0.6, sodium: 876, serving: "100g" },

  // Grains & Carbs (25 items)
  { name: "White Rice", calories: 130, protein: 2.7, carbs: 28.0, fat: 0.3, fiber: 0.4, sugar: 0.1, sodium: 1, serving: "100g" },
  { name: "Brown Rice", calories: 111, protein: 2.6, carbs: 23.0, fat: 0.9, fiber: 1.8, sugar: 0.4, sodium: 5, serving: "100g" },
  { name: "Quinoa", calories: 120, protein: 4.4, carbs: 21.3, fat: 1.9, fiber: 2.8, sugar: 0.9, sodium: 7, serving: "100g" },
  { name: "Oatmeal", calories: 68, protein: 2.4, carbs: 12.0, fat: 1.4, fiber: 1.7, sugar: 0.5, sodium: 2, serving: "100g" },
  { name: "Oats (rolled)", calories: 389, protein: 16.9, carbs: 66.3, fat: 6.9, fiber: 10.6, sugar: 0.0, sodium: 2, serving: "100g" },
  { name: "Whole Wheat Bread", calories: 247, protein: 13.0, carbs: 41.0, fat: 3.4, fiber: 6.0, sugar: 5.6, sodium: 400, serving: "100g" },
  { name: "White Bread", calories: 265, protein: 9.0, carbs: 49.0, fat: 3.2, fiber: 2.7, sugar: 5.0, sodium: 490, serving: "100g" },
  { name: "Sourdough Bread", calories: 289, protein: 12.0, carbs: 56.0, fat: 1.8, fiber: 2.4, sugar: 1.2, sodium: 580, serving: "100g" },
  { name: "Pita Bread", calories: 275, protein: 9.1, carbs: 55.7, fat: 1.2, fiber: 2.2, sugar: 1.8, sodium: 536, serving: "100g" },
  { name: "Bagel", calories: 250, protein: 10.0, carbs: 48.0, fat: 1.5, fiber: 2.3, sugar: 6.0, sodium: 439, serving: "100g" },
  { name: "Croissant", calories: 406, protein: 8.2, carbs: 45.8, fat: 21.0, fiber: 2.6, sugar: 11.2, sodium: 467, serving: "100g" },
  { name: "Naan", calories: 310, protein: 9.0, carbs: 50.0, fat: 6.0, fiber: 2.0, sugar: 3.0, sodium: 450, serving: "100g" },
  { name: "Pasta (wheat)", calories: 124, protein: 5.3, carbs: 25.0, fat: 0.6, fiber: 2.8, sugar: 0.8, sodium: 4, serving: "100g" },
  { name: "Pasta (white)", calories: 158, protein: 5.8, carbs: 31.0, fat: 0.9, fiber: 1.8, sugar: 0.6, sodium: 1, serving: "100g" },
  { name: "Egg Noodles", calories: 138, protein: 4.5, carbs: 25.0, fat: 2.1, fiber: 1.2, sugar: 1.0, sodium: 8, serving: "100g" },
  { name: "Rice Noodles", calories: 108, protein: 1.2, carbs: 24.0, fat: 0.2, fiber: 1.0, sugar: 0.1, sodium: 18, serving: "100g" },
  { name: "Couscous", calories: 112, protein: 3.8, carbs: 23.0, fat: 0.2, fiber: 1.4, sugar: 0.1, sodium: 5, serving: "100g" },
  { name: "Barley", calories: 123, protein: 2.3, carbs: 28.0, fat: 0.4, fiber: 3.8, sugar: 0.3, sodium: 3, serving: "100g" },
  { name: "Rye", calories: 338, protein: 10.3, carbs: 75.9, fat: 1.6, fiber: 15.1, sugar: 1.0, sodium: 2, serving: "100g" },
  { name: "Buckwheat", calories: 343, protein: 13.3, carbs: 71.5, fat: 3.4, fiber: 10.0, sugar: 2.0, sodium: 1, serving: "100g" },
  { name: "Tortilla (corn)", calories: 218, protein: 5.7, carbs: 45.0, fat: 2.9, fiber: 6.3, sugar: 0.9, sodium: 45, serving: "100g" },
  { name: "Tortilla (flour)", calories: 297, protein: 7.9, carbs: 50.0, fat: 7.6, fiber: 2.4, sugar: 1.8, sodium: 680, serving: "100g" },
  { name: "Granola", calories: 471, protein: 10.0, carbs: 64.0, fat: 20.0, fiber: 8.0, sugar: 20.0, sodium: 290, serving: "100g" },
  { name: "Cornflakes", calories: 357, protein: 8.0, carbs: 84.0, fat: 0.4, fiber: 3.3, sugar: 10.0, sodium: 729, serving: "100g" },
  { name: "Polenta", calories: 70, protein: 2.0, carbs: 15.0, fat: 0.5, fiber: 1.0, sugar: 0.0, sodium: 0, serving: "100g" },

  // Legumes & Nuts (25 items)
  { name: "Almonds", calories: 579, protein: 21.2, carbs: 21.6, fat: 49.9, fiber: 12.5, sugar: 4.4, sodium: 1, serving: "100g" },
  { name: "Walnuts", calories: 654, protein: 15.2, carbs: 13.7, fat: 65.2, fiber: 6.7, sugar: 2.6, sodium: 2, serving: "100g" },
  { name: "Cashews", calories: 553, protein: 18.2, carbs: 30.2, fat: 43.8, fiber: 3.3, sugar: 5.9, sodium: 12, serving: "100g" },
  { name: "Pistachios", calories: 562, protein: 20.3, carbs: 27.5, fat: 45.4, fiber: 10.3, sugar: 7.7, sodium: 1, serving: "100g" },
  { name: "Peanuts", calories: 567, protein: 25.8, carbs: 16.1, fat: 49.2, fiber: 8.5, sugar: 4.7, sodium: 18, serving: "100g" },
  { name: "Pecans", calories: 691, protein: 9.2, carbs: 13.9, fat: 72.0, fiber: 9.6, sugar: 4.0, sodium: 0, serving: "100g" },
  { name: "Macadamia", calories: 718, protein: 7.9, carbs: 13.8, fat: 75.8, fiber: 8.6, sugar: 4.6, sodium: 5, serving: "100g" },
  { name: "Pumpkin Seeds", calories: 559, protein: 30.2, carbs: 10.7, fat: 49.0, fiber: 6.0, sugar: 1.4, sodium: 7, serving: "100g" },
  { name: "Sunflower Seeds", calories: 584, protein: 20.8, carbs: 20.0, fat: 51.5, fiber: 8.6, sugar: 2.6, sodium: 9, serving: "100g" },
  { name: "Chia Seeds", calories: 486, protein: 16.5, carbs: 42.1, fat: 30.7, fiber: 34.4, sugar: 0.0, sodium: 16, serving: "100g" },
  { name: "Flax Seeds", calories: 534, protein: 18.3, carbs: 28.9, fat: 42.2, fiber: 27.3, sugar: 1.6, sodium: 30, serving: "100g" },
  { name: "Sesame Seeds", calories: 573, protein: 17.7, carbs: 23.4, fat: 49.7, fiber: 11.8, sugar: 0.3, sodium: 11, serving: "100g" },
  { name: "Peanut Butter", calories: 588, protein: 25.0, carbs: 20.0, fat: 50.0, fiber: 6.0, sugar: 9.0, sodium: 429, serving: "100g" },
  { name: "Almond Butter", calories: 614, protein: 21.0, carbs: 19.0, fat: 56.0, fiber: 10.0, sugar: 5.0, sodium: 4, serving: "100g" },
  { name: "Tahini", calories: 595, protein: 17.0, carbs: 21.0, fat: 54.0, fiber: 9.0, sugar: 0.5, sodium: 115, serving: "100g" },
  { name: "Tofu (firm)", calories: 76, protein: 8.0, carbs: 1.9, fat: 4.8, fiber: 0.3, sugar: 0.3, sodium: 7, serving: "100g" },
  { name: "Tofu (silken)", calories: 55, protein: 4.8, carbs: 2.0, fat: 2.7, fiber: 0.1, sugar: 0.5, sodium: 4, serving: "100g" },
  { name: "Tempeh", calories: 193, protein: 19.0, carbs: 9.0, fat: 11.0, fiber: 0.0, sugar: 0.0, sodium: 9, serving: "100g" },
  { name: "Seitan", calories: 370, protein: 75.0, carbs: 14.0, fat: 1.9, fiber: 0.0, sugar: 0.0, sodium: 100, serving: "100g" },
  { name: "Edamame", calories: 122, protein: 11.0, carbs: 10.0, fat: 5.0, fiber: 5.2, sugar: 2.2, sodium: 6, serving: "100g" },
  { name: "Hummus", calories: 166, protein: 7.9, carbs: 14.3, fat: 9.6, fiber: 6.0, sugar: 1.4, sodium: 379, serving: "100g" },
  { name: "Falafel", calories: 333, protein: 13.3, carbs: 31.8, fat: 17.8, fiber: 4.9, sugar: 4.8, sodium: 294, serving: "100g" },
  { name: "Lentils", calories: 116, protein: 9.0, carbs: 20.0, fat: 0.4, fiber: 7.9, sugar: 1.8, sodium: 2, serving: "100g" },
  { name: "Black Beans", calories: 132, protein: 8.9, carbs: 23.7, fat: 0.5, fiber: 8.7, sugar: 0.3, sodium: 1, serving: "100g" },
  { name: "Chickpeas", calories: 164, protein: 8.9, carbs: 27.4, fat: 2.6, fiber: 7.6, sugar: 4.8, sodium: 24, serving: "100g" },

  // Prepared & Fast Foods (25 items)
  { name: "Pizza Margherita", calories: 250, protein: 10.5, carbs: 30.0, fat: 10.0, fiber: 1.5, sugar: 2.5, sodium: 550, serving: "100g" },
  { name: "Pepperoni Pizza", calories: 298, protein: 11.4, carbs: 28.5, fat: 15.0, fiber: 1.6, sugar: 2.2, sodium: 680, serving: "100g" },
  { name: "Hamburger", calories: 254, protein: 13.0, carbs: 30.0, fat: 9.0, fiber: 1.5, sugar: 4.0, sodium: 480, serving: "100g" },
  { name: "Cheeseburger", calories: 263, protein: 15.0, carbs: 28.0, fat: 12.0, fiber: 1.5, sugar: 4.5, sodium: 580, serving: "100g" },
  { name: "Hot Dog", calories: 290, protein: 10.0, carbs: 25.0, fat: 18.0, fiber: 1.0, sugar: 3.0, sodium: 620, serving: "100g" },
  { name: "Chicken Nuggets", calories: 296, protein: 15.0, carbs: 16.0, fat: 20.0, fiber: 1.0, sugar: 0.5, sodium: 550, serving: "100g" },
  { name: "French Fries", calories: 312, protein: 3.4, carbs: 41.0, fat: 15.0, fiber: 3.8, sugar: 0.3, sodium: 210, serving: "100g" },
  { name: "Onion Rings", calories: 411, protein: 4.5, carbs: 44.0, fat: 24.0, fiber: 2.3, sugar: 4.0, sodium: 350, serving: "100g" },
  { name: "Club Sandwich", calories: 235, protein: 12.0, carbs: 22.0, fat: 11.0, fiber: 1.8, sugar: 2.5, sodium: 640, serving: "100g" },
  { name: "BLT", calories: 242, protein: 9.0, carbs: 23.0, fat: 13.0, fiber: 1.7, sugar: 2.8, sodium: 590, serving: "100g" },
  { name: "Caesar Salad", calories: 120, protein: 2.5, carbs: 4.0, fat: 11.0, fiber: 1.2, sugar: 1.0, sodium: 280, serving: "100g" },
  { name: "Chicken Salad", calories: 162, protein: 14.0, carbs: 3.0, fat: 11.0, fiber: 0.8, sugar: 1.5, sodium: 340, serving: "100g" },
  { name: "Taco", calories: 226, protein: 11.0, carbs: 20.0, fat: 11.0, fiber: 2.5, sugar: 1.5, sodium: 430, serving: "100g" },
  { name: "Burrito", calories: 206, protein: 8.0, carbs: 26.0, fat: 8.0, fiber: 2.2, sugar: 1.5, sodium: 450, serving: "100g" },
  { name: "Quesadilla", calories: 293, protein: 14.0, carbs: 27.0, fat: 14.0, fiber: 1.5, sugar: 1.5, sodium: 550, serving: "100g" },
  { name: "Sushi", calories: 143, protein: 4.5, carbs: 29.0, fat: 1.0, fiber: 0.8, sugar: 3.5, sodium: 320, serving: "100g" },
  { name: "Pasta Carbonara", calories: 215, protein: 8.5, carbs: 24.0, fat: 9.5, fiber: 1.2, sugar: 1.0, sodium: 420, serving: "100g" },
  { name: "Pasta Bolognese", calories: 145, protein: 7.2, carbs: 18.0, fat: 5.0, fiber: 1.5, sugar: 2.2, sodium: 350, serving: "100g" },
  { name: "Lasagna", calories: 168, protein: 10.5, carbs: 14.0, fat: 8.0, fiber: 1.2, sugar: 2.5, sodium: 390, serving: "100g" },
  { name: "Mac and Cheese", calories: 164, protein: 6.9, carbs: 22.0, fat: 5.4, fiber: 1.0, sugar: 2.0, sodium: 450, serving: "100g" },
  { name: "Pancake", calories: 227, protein: 6.4, carbs: 28.0, fat: 10.0, fiber: 1.0, sugar: 6.0, sodium: 439, serving: "100g" },
  { name: "Waffle", calories: 291, protein: 7.9, carbs: 32.9, fat: 14.0, fiber: 1.0, sugar: 8.0, sodium: 512, serving: "100g" },
  { name: "Donut", calories: 426, protein: 4.9, carbs: 51.0, fat: 22.0, fiber: 1.5, sugar: 26.0, sodium: 370, serving: "100g" },
  { name: "Blueberry Muffin", calories: 377, protein: 5.0, carbs: 51.5, fat: 16.0, fiber: 1.8, sugar: 29.0, sodium: 310, serving: "100g" },
  { name: "Chocolate Chip Cookie", calories: 488, protein: 5.0, carbs: 62.0, fat: 24.0, fiber: 2.0, sugar: 34.0, sodium: 290, serving: "100g" },

  // Beverages & Oils (20 items)
  { name: "Olive Oil", calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, fiber: 0.0, sugar: 0.0, sodium: 2, serving: "100g" },
  { name: "Coconut Oil", calories: 862, protein: 0.0, carbs: 0.0, fat: 100.0, fiber: 0.0, sugar: 0.0, sodium: 1, serving: "100g" },
  { name: "Avocado Oil", calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, fiber: 0.0, sugar: 0.0, sodium: 0, serving: "100g" },
  { name: "Canola Oil", calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, fiber: 0.0, sugar: 0.0, sodium: 0, serving: "100g" },
  { name: "Sesame Oil", calories: 884, protein: 0.0, carbs: 0.0, fat: 100.0, fiber: 0.0, sugar: 0.0, sodium: 0, serving: "100g" },
  { name: "Honey", calories: 304, protein: 0.3, carbs: 82.4, fat: 0.0, fiber: 0.2, sugar: 82.1, sodium: 4, serving: "100g" },
  { name: "Maple Syrup", calories: 260, protein: 0.0, carbs: 67.0, fat: 0.1, fiber: 0.0, sugar: 60.0, sodium: 12, serving: "100g" },
  { name: "Agave Nectar", calories: 310, protein: 0.0, carbs: 76.0, fat: 0.5, fiber: 0.2, sugar: 68.0, sodium: 4, serving: "100g" },
  { name: "White Sugar", calories: 387, protein: 0.0, carbs: 100.0, fat: 0.0, fiber: 0.0, sugar: 100.0, sodium: 1, serving: "100g" },
  { name: "Brown Sugar", calories: 380, protein: 0.0, carbs: 98.0, fat: 0.0, fiber: 0.0, sugar: 97.0, sodium: 28, serving: "100g" },
  { name: "Dark Chocolate", calories: 546, protein: 4.9, carbs: 61.0, fat: 31.0, fiber: 7.0, sugar: 48.0, sodium: 20, serving: "100g" },
  { name: "Milk Chocolate", calories: 535, protein: 7.6, carbs: 59.4, fat: 29.7, fiber: 3.4, sugar: 51.5, sodium: 79, serving: "100g" },
  { name: "Coca-Cola", calories: 37, protein: 0.0, carbs: 10.6, fat: 0.0, fiber: 0.0, sugar: 10.6, sodium: 4, serving: "100g" },
  { name: "Diet Coke", calories: 0, protein: 0.0, carbs: 0.0, fat: 0.0, fiber: 0.0, sugar: 0.0, sodium: 10, serving: "100g" },
  { name: "Orange Juice", calories: 45, protein: 0.7, carbs: 10.4, fat: 0.2, fiber: 0.2, sugar: 8.4, sodium: 1, serving: "100g" },
  { name: "Apple Juice", calories: 46, protein: 0.1, carbs: 11.3, fat: 0.1, fiber: 0.2, sugar: 9.6, sodium: 4, serving: "100g" },
  { name: "Beer", calories: 43, protein: 0.5, carbs: 3.6, fat: 0.0, fiber: 0.0, sugar: 0.0, sodium: 4, serving: "100g" },
  { name: "Red Wine", calories: 85, protein: 0.1, carbs: 2.6, fat: 0.0, fiber: 0.0, sugar: 0.6, sodium: 4, serving: "100g" },
  { name: "White Wine", calories: 82, protein: 0.1, carbs: 2.6, fat: 0.0, fiber: 0.0, sugar: 1.0, sodium: 5, serving: "100g" },
  { name: "Black Coffee", calories: 1, protein: 0.1, carbs: 0.0, fat: 0.0, fiber: 0.0, sugar: 0.0, sodium: 2, serving: "100g" }
];

export function localFuzzySearch(query: string): FoodItem | null {
  const q = query.toLowerCase().trim();
  if (!q) return null;

  // Exact match
  let matched = localFoodDb.find(f => f.name.toLowerCase() === q);
  if (matched) return matched;

  // Starts with match
  matched = localFoodDb.find(f => f.name.toLowerCase().startsWith(q));
  if (matched) return matched;

  // Substring match
  matched = localFoodDb.find(f => f.name.toLowerCase().includes(q));
  if (matched) return matched;

  // Words split match
  const words = q.split(/\s+/);
  matched = localFoodDb.find(f => words.every(word => f.name.toLowerCase().includes(word)));
  if (matched) return matched;

  // Word partial fallback
  matched = localFoodDb.find(f => words.some(word => f.name.toLowerCase().includes(word)));
  if (matched) return matched;

  return null;
}

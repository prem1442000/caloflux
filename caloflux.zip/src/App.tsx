/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Camera, Flame, Plus, Minus, Search, User, LogOut, Check, ChevronLeft, ChevronRight, 
  Settings, Droplet, Dumbbell, Calendar, AlertTriangle, Eye, EyeOff, Loader2, Sparkles, 
  Activity, Award, RefreshCw, Smartphone, TrendingUp, Info, HelpCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Camera as CapCamera, CameraResultType, CameraSource } from "@capacitor/camera";
import { FoodItem, FOOD_LABELS, localFoodDb, localFuzzySearch } from "./localDb";

// UI Theme Colors mapping
const C = {
  bg: '#07070f',
  card: '#12121c',
  cardDark: '#07070f',
  border: 'rgba(75, 85, 99, 0.2)',
  accent: '#3b82f6', // Blue
  accentLight: '#60a5fa',
  green: '#10b981',
  orange: '#f97316',
  yellow: '#facc15',
  red: '#ef4444',
  text: '#ffffff',
  textMuted: '#9b9ba6',
};

interface UserSession {
  email: string;
  name: string;
  onboarded: boolean;
  gender: 'male' | 'female' | 'other';
  age: number;
  height: number; // cm
  weight: number; // kg
  goal: 'lose' | 'maintain' | 'gain';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active';
  targetCalories: number;
  targetProtein: number; // g
  targetCarbs: number;   // g
  targetFat: number;     // g
}

interface MealLog {
  id: string;
  date: string; // YYYY-MM-DD
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
  servingAmount: number; // in grams
  mealType: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks';
  source: 'USDA' | 'Open Food Facts' | 'Local DB';
  confidence?: number;
}

export default function App() {
  // --- STATE DECLARATIONS ---
  const [session, setSession] = useState<UserSession | null>(null);
  const [authView, setAuthView] = useState<'login' | 'signup'>('login');
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authError, setAuthError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Onboarding Wizard state
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('male');
  const [age, setAge] = useState(25);
  const [height, setHeight] = useState(175);
  const [weight, setWeight] = useState(70);
  const [goal, setGoal] = useState<'lose' | 'maintain' | 'gain'>('lose');
  const [activityLevel, setActivityLevel] = useState<'sedentary' | 'light' | 'moderate' | 'active'>('moderate');

  // Navigation & Date State
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'log' | 'profile'>('dashboard');
  const [selectedDate, setSelectedDate] = useState("");

  // Hydration State (Stored as record of { "YYYY-MM-DD": count_in_cups })
  const [waterIntake, setWaterIntake] = useState<Record<string, number>>({});

  // Meal Logs State
  const [logs, setLogs] = useState<MealLog[]>([]);

  // Burned workout State (Stored as record of { "YYYY-MM-DD": calories_burned })
  const [workoutCalories, setWorkoutCalories] = useState<Record<string, number>>({});
  const [showWorkoutModal, setShowWorkoutModal] = useState(false);
  const [customWorkoutName, setCustomWorkoutName] = useState("");
  const [customWorkoutCals, setCustomWorkoutCals] = useState("");

  // Model Loading State
  const mobilenetModelRef = useRef<any>(null);
  const [modelLoadingState, setModelLoadingState] = useState<'unloaded' | 'loading' | 'ready'>('unloaded');

  // Food logging / Scanning views
  const [activeLogMealType, setActiveLogMealType] = useState<'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks' | null>(null);
  const [foodSearchQuery, setFoodSearchQuery] = useState("");
  const [localSearchResults, setLocalSearchResults] = useState<FoodItem[]>([]);
  const [selectedFoodItem, setSelectedFoodItem] = useState<FoodItem | null>(null);
  const [selectedFoodSource, setSelectedFoodSource] = useState<'USDA' | 'Open Food Facts' | 'Local DB'>('Local DB');
  const [selectedFoodConfidence, setSelectedFoodConfidence] = useState<number>(100);

  // Photo scanning Pipeline state
  const [photoProcessingState, setPhotoProcessingState] = useState<'idle' | 'opening_camera' | 'analyzing' | 'looking_up' | 'success' | 'error'>('idle');
  const [photoProcessingError, setPhotoProcessingError] = useState("");
  const [capturedImagePreview, setCapturedImagePreview] = useState<string | null>(null);
  const [portionAmount, setPortionAmount] = useState(100); // in grams
  const [detectedFoodResult, setDetectedFoodResult] = useState<{
    name: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    sugar: number;
    sodium: number;
    detectedLabel?: string;
    mlConfidence?: number;
    source?: 'USDA' | 'Open Food Facts' | 'Local DB';
  } | null>(null);

  // Refs for hidden file inputs
  const fileInputRefCamera = useRef<HTMLInputElement>(null);
  const fileInputRefLibrary = useRef<HTMLInputElement>(null);

  // Set default date to today's local date string on mount
  useEffect(() => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    setSelectedDate(`${year}-${month}-${day}`);
  }, []);

  // --- MODEL SILENT BACKGROUND LOADING ---
  useEffect(() => {
    async function initModel() {
      if ((window as any).mobilenet) {
        setModelLoadingState('loading');
        try {
          const model = await (window as any).mobilenet.load({ version: 2, alpha: 1.0 });
          mobilenetModelRef.current = model;
          setModelLoadingState('ready');
          console.log("MobileNet successfully pre-loaded in the background.");
        } catch (error) {
          console.error("Failed to load MobileNet model silently:", error);
          setModelLoadingState('unloaded');
        }
      } else {
        console.warn("MobileNet CDN scripts not available yet.");
      }
    }
    // Give browser a split second to register CDN scripts
    const timer = setTimeout(() => {
      initModel();
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  // --- PERSISTENCE LOAD ON SESSION CHANGE ---
  useEffect(() => {
    // Attempt to load current session
    const storedSession = localStorage.getItem("caloflux_session");
    if (storedSession) {
      try {
        const parsedSession = JSON.parse(storedSession);
        setSession(parsedSession);
        
        // Load data specific to this user email
        const email = parsedSession.email;
        const savedLogs = localStorage.getItem(`caloflux_logs_${email}`);
        if (savedLogs) setLogs(JSON.parse(savedLogs));
        
        const savedWater = localStorage.getItem(`caloflux_water_${email}`);
        if (savedWater) setWaterIntake(JSON.parse(savedWater));

        const savedWorkouts = localStorage.getItem(`caloflux_workouts_${email}`);
        if (savedWorkouts) setWorkoutCalories(JSON.parse(savedWorkouts));

        // Load profile variables into onboarding controls in case they need to re-onboard or view profile
        setGender(parsedSession.gender || 'male');
        setAge(parsedSession.age || 25);
        setHeight(parsedSession.height || 175);
        setWeight(parsedSession.weight || 70);
        setGoal(parsedSession.goal || 'lose');
        setActivityLevel(parsedSession.activityLevel || 'moderate');
      } catch (e) {
        console.error("Error loading session:", e);
      }
    }
  }, []);

  // Save logs to localStorage
  const saveLogs = (newLogs: MealLog[]) => {
    setLogs(newLogs);
    if (session) {
      localStorage.setItem(`caloflux_logs_${session.email}`, JSON.stringify(newLogs));
    }
  };

  // Save water to localStorage
  const saveWater = (newWater: Record<string, number>) => {
    setWaterIntake(newWater);
    if (session) {
      localStorage.setItem(`caloflux_water_${session.email}`, JSON.stringify(newWater));
    }
  };

  // Save workouts to localStorage
  const saveWorkouts = (newWorkouts: Record<string, number>) => {
    setWorkoutCalories(newWorkouts);
    if (session) {
      localStorage.setItem(`caloflux_workouts_${session.email}`, JSON.stringify(newWorkouts));
    }
  };

  // --- CALCULATION HELPERS ---
  const handleCalculateTDEE = (w: number, h: number, a: number, g: 'male' | 'female' | 'other', act: 'sedentary' | 'light' | 'moderate' | 'active') => {
    // Mifflin-St Jeor Formula
    let bmr = 0;
    if (g === 'male') {
      bmr = 10 * w + 6.25 * h - 5 * a + 5;
    } else {
      bmr = 10 * w + 6.25 * h - 5 * a - 161;
    }

    const activityMultipliers = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725
    };

    const tdee = Math.round(bmr * activityMultipliers[act]);
    return tdee;
  };

  // --- AUTH ACTIONS ---
  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");

    if (!authEmail || !authPassword) {
      setAuthError("Please fill out all fields.");
      return;
    }

    const savedUsersStr = localStorage.getItem("caloflux_users") || "[]";
    const users = JSON.parse(savedUsersStr);

    if (authView === 'signup') {
      if (!authName) {
        setAuthError("Please enter your name.");
        return;
      }
      const existingUser = users.find((u: any) => u.email === authEmail.toLowerCase());
      if (existingUser) {
        setAuthError("Email already in use.");
        return;
      }

      const newUser = {
        name: authName,
        email: authEmail.toLowerCase(),
        password: authPassword,
      };
      users.push(newUser);
      localStorage.setItem("caloflux_users", JSON.stringify(users));

      // Initiate default session for onboarding
      const initialSession: UserSession = {
        email: authEmail.toLowerCase(),
        name: authName,
        onboarded: false,
        gender: 'male',
        age: 25,
        height: 170,
        weight: 65,
        goal: 'lose',
        activityLevel: 'moderate',
        targetCalories: 2000,
        targetProtein: 130,
        targetCarbs: 220,
        targetFat: 65
      };

      localStorage.setItem("caloflux_session", JSON.stringify(initialSession));
      setSession(initialSession);
      setOnboardingStep(1);
    } else {
      const user = users.find(
        (u: any) => u.email === authEmail.toLowerCase() && u.password === authPassword
      );
      if (!user) {
        setAuthError("Invalid email or password.");
        return;
      }

      // Check if this user had a profile set up before
      const savedProfile = localStorage.getItem(`caloflux_profile_${user.email}`);
      let currentSession: UserSession;

      if (savedProfile) {
        currentSession = JSON.parse(savedProfile);
      } else {
        currentSession = {
          email: user.email,
          name: user.name,
          onboarded: false,
          gender: 'male',
          age: 25,
          height: 170,
          weight: 65,
          goal: 'lose',
          activityLevel: 'moderate',
          targetCalories: 2000,
          targetProtein: 130,
          targetCarbs: 220,
          targetFat: 65
        };
      }

      localStorage.setItem("caloflux_session", JSON.stringify(currentSession));
      setSession(currentSession);
      
      // Load user logs and other metrics
      const savedLogs = localStorage.getItem(`caloflux_logs_${user.email}`);
      if (savedLogs) setLogs(JSON.parse(savedLogs));
      
      const savedWater = localStorage.getItem(`caloflux_water_${user.email}`);
      if (savedWater) setWaterIntake(JSON.parse(savedWater));

      const savedWorkouts = localStorage.getItem(`caloflux_workouts_${user.email}`);
      if (savedWorkouts) setWorkoutCalories(JSON.parse(savedWorkouts));
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("caloflux_session");
    setSession(null);
    setAuthEmail("");
    setAuthPassword("");
    setAuthName("");
    setAuthError("");
    setLogs([]);
    setWaterIntake({});
    setWorkoutCalories({});
    setCurrentTab('dashboard');
  };

  // --- ONBOARDING SAVE ---
  const saveOnboarding = () => {
    if (!session) return;

    const tdee = handleCalculateTDEE(weight, height, age, gender, activityLevel);
    let targetCalories = tdee;
    
    // Macro breakdowns:
    // Protein: 4 kcal/g, Carbs: 4 kcal/g, Fat: 9 kcal/g
    let pPct = 0.30;
    let cPct = 0.40;
    let fPct = 0.30;

    if (goal === 'lose') {
      targetCalories = tdee - 500;
      pPct = 0.35; // higher protein on deficit
      cPct = 0.35;
      fPct = 0.30;
    } else if (goal === 'gain') {
      targetCalories = tdee + 500;
      pPct = 0.25;
      cPct = 0.50;
      fPct = 0.25;
    }

    const targetProtein = Math.round((targetCalories * pPct) / 4);
    const targetCarbs = Math.round((targetCalories * cPct) / 4);
    const targetFat = Math.round((targetCalories * fPct) / 9);

    const updatedSession: UserSession = {
      ...session,
      onboarded: true,
      gender,
      age,
      height,
      weight,
      goal,
      activityLevel,
      targetCalories,
      targetProtein,
      targetCarbs,
      targetFat
    };

    localStorage.setItem(`caloflux_profile_${session.email}`, JSON.stringify(updatedSession));
    localStorage.setItem("caloflux_session", JSON.stringify(updatedSession));
    setSession(updatedSession);
  };

  // --- WATER CONTROL ---
  const adjustWater = (amount: number) => {
    const currentCups = waterIntake[selectedDate] || 0;
    const nextCups = Math.max(0, currentCups + amount);
    saveWater({
      ...waterIntake,
      [selectedDate]: nextCups
    });
  };

  // --- WORKOUT LOGGING ---
  const handleAddWorkout = (e: React.FormEvent) => {
    e.preventDefault();
    const cals = parseInt(customWorkoutCals);
    if (!cals || cals <= 0) return;

    const currentBurned = workoutCalories[selectedDate] || 0;
    saveWorkouts({
      ...workoutCalories,
      [selectedDate]: currentBurned + cals
    });

    setCustomWorkoutCals("");
    setCustomWorkoutName("");
    setShowWorkoutModal(false);
  };

  // --- FUZZY SEARCH TRIGGER ---
  const handleSearchChange = (query: string) => {
    setFoodSearchQuery(query);
    if (query.trim().length > 0) {
      const results: FoodItem[] = [];
      const queryLower = query.toLowerCase().trim();
      
      // Let's filter localFoodDb
      localFoodDb.forEach(food => {
        if (food.name.toLowerCase().includes(queryLower)) {
          results.push(food);
        }
      });
      setLocalSearchResults(results.slice(0, 15));
    } else {
      setLocalSearchResults([]);
    }
  };

  // --- USDA API SEARCH LOOKUP ---
  async function lookupUSDA(foodName: string) {
    const url = `https://api.nal.usda.gov/fdc/v1/foods/search?query=${encodeURIComponent(foodName)}&api_key=DEMO_KEY&dataType=SR%20Legacy,Survey%20(FNDDS)&pageSize=1`;
    const res = await fetch(url);
    const data = await res.json();
    const food = data.foods?.[0];
    if (!food) return null;

    // Nutrient IDs mapping
    const getNutrient = (id: number, names: string[]) => {
      const nutrient = food.foodNutrients?.find((n: any) => 
        n.nutrientId === id || (n.nutrientName && names.some(name => n.nutrientName.toLowerCase().includes(name.toLowerCase())))
      );
      return nutrient ? nutrient.value : 0;
    };

    return {
      name: food.description,
      calories: Math.round(getNutrient(1008, ['energy', 'calorie'])),
      protein:  Math.round(getNutrient(1003, ['protein']) * 10) / 10,
      carbs:    Math.round(getNutrient(1005, ['carbohydrate']) * 10) / 10,
      fat:      Math.round(getNutrient(1004, ['total lipid', 'fat']) * 10) / 10,
      fiber:    Math.round(getNutrient(1079, ['fiber']) * 10) / 10,
      sugar:    Math.round(getNutrient(2000, ['sugar']) * 10) / 10,
      sodium:   Math.round(getNutrient(1093, ['sodium'])),
      serving:  "100g",
    };
  }

  // --- OPEN FOOD FACTS LOOKUP ---
  async function lookupOpenFoodFacts(foodName: string) {
    const url = `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(foodName)}&search_simple=1&action=process&json=1&page_size=1`;
    const res = await fetch(url);
    const data = await res.json();
    const product = data.products?.[0];
    if (!product?.nutriments) return null;
    const n = product.nutriments;
    return {
      name: product.product_name || foodName,
      calories: Math.round(n["energy-kcal_100g"] || n["energy_100g"] / 4.184 || 0),
      protein:  Math.round((n["proteins_100g"] || 0) * 10) / 10,
      carbs:    Math.round((n["carbohydrates_100g"] || 0) * 10) / 10,
      fat:      Math.round((n["fat_100g"] || 0) * 10) / 10,
      fiber:    Math.round((n["fiber_100g"] || 0) * 10) / 10,
      sugar:    Math.round((n["sugars_100g"] || 0) * 10) / 10,
      sodium:   Math.round((n["sodium_100g"] || 0) * 1000),
      serving:  "100g",
    };
  }

  // --- PHOTO ANALYSIS PIPELINE ---
  async function runPhotoInference(imageSrc: string) {
    setPhotoProcessingError("");
    setPhotoProcessingState('analyzing');

    // Make sure we have MobileNet model loaded
    let model = mobilenetModelRef.current;
    if (!model) {
      if (!(window as any).mobilenet) {
        setPhotoProcessingState('error');
        setPhotoProcessingError("TensorFlow.js classification model is unavailable. Try typing instead.");
        return;
      }
      try {
        model = await (window as any).mobilenet.load({ version: 2, alpha: 1.0 });
        mobilenetModelRef.current = model;
      } catch (err) {
        setPhotoProcessingState('error');
        setPhotoProcessingError("Failed to initialize classification engine. Check internet connection.");
        return;
      }
    }

    // 1. Convert DataURL/ImageSrc to HTMLImageElement
    let imgElement: HTMLImageElement;
    try {
      imgElement = await new Promise<HTMLImageElement>((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error("Could not parse captured photo."));
        img.src = imageSrc;
      });
    } catch (e) {
      setPhotoProcessingState('error');
      setPhotoProcessingError("Failed to render the photo for analysis.");
      return;
    }

    // 2. Classify image with MobileNet
    let predictions: any[] = [];
    try {
      predictions = await model.classify(imgElement, 5);
      console.log("TF.js Inference output predictions:", predictions);
    } catch (err) {
      setPhotoProcessingState('error');
      setPhotoProcessingError("On-device classification failed. Please try again.");
      return;
    }

    // 3. Filter to food-relevant classes
    const foodPreds = predictions.filter(p =>
      FOOD_LABELS.some(label => p.className.toLowerCase().includes(label)) ||
      ["carbonara", "spaghetti", "macaroni", "custard", "doughnut", "potpie", "meat loaf", "eggnog", "espresso"].some(label => p.className.toLowerCase().includes(label))
    );

    if (foodPreds.length === 0 || foodPreds[0].probability < 0.22) {
      setPhotoProcessingState('error');
      setPhotoProcessingError("Could not confidently identify food. Try a clearer photo with proper lighting.");
      return;
    }

    const topPrediction = foodPreds[0];
    let topFoodLabel = topPrediction.className.split(",")[0].trim();
    
    // Quick labels cleaner mapping
    if (topFoodLabel.toLowerCase() === "carbonara") topFoodLabel = "Pasta Carbonara";
    if (topFoodLabel.toLowerCase() === "french loaf") topFoodLabel = "White Bread";
    if (topFoodLabel.toLowerCase() === "potpie") topFoodLabel = "Chicken Pie";

    const mlConfidence = Math.round(topPrediction.probability * 100);

    // 4. Look up nutrition (Waterfall sequence)
    setPhotoProcessingState('looking_up');
    let nutrition: any = null;
    let sourceUsed: 'USDA' | 'Open Food Facts' | 'Local DB' = 'USDA';

    // (A) Try USDA primary
    try {
      console.log(`Querying USDA for: ${topFoodLabel}`);
      nutrition = await lookupUSDA(topFoodLabel);
      if (nutrition) sourceUsed = 'USDA';
    } catch (e) {
      console.warn("USDA API threw error, cascading to Open Food Facts", e);
    }

    // (B) Try Open Food Facts fallback
    if (!nutrition) {
      try {
        console.log(`Querying Open Food Facts for: ${topFoodLabel}`);
        nutrition = await lookupOpenFoodFacts(topFoodLabel);
        if (nutrition) sourceUsed = 'Open Food Facts';
      } catch (e) {
        console.warn("Open Food Facts API threw error, cascading to local DB", e);
      }
    }

    // (C) Try local DB final fallback
    if (!nutrition) {
      console.log(`Falling back to local DB for: ${topFoodLabel}`);
      const localMatch = localFuzzySearch(topFoodLabel);
      if (localMatch) {
        nutrition = localMatch;
        sourceUsed = 'Local DB';
      }
    }

    // If still nothing, provide fallback alert
    if (!nutrition) {
      setPhotoProcessingState('error');
      setPhotoProcessingError(`Identified "${topFoodLabel}" (${mlConfidence}% confidence) but couldn't load nutrient levels. Try a text search.`);
      return;
    }

    // Successfully loaded nutrition!
    setDetectedFoodResult({
      ...nutrition,
      detectedLabel: topFoodLabel,
      mlConfidence,
      source: sourceUsed
    });
    setPortionAmount(100);
    setPhotoProcessingState('success');
  }

  // --- CAPACITOR OR FILE INPUT DISPATCHERS ---
  const handleTakePhotoNative = async () => {
    setCapturedImagePreview(null);
    setDetectedFoodResult(null);

    try {
      // First try Capacitor Native Camera
      setPhotoProcessingState('opening_camera');
      const photo = await CapCamera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera,
      });

      if (photo?.dataUrl) {
        setCapturedImagePreview(photo.dataUrl);
        runPhotoInference(photo.dataUrl);
      } else {
        setPhotoProcessingState('idle');
      }
    } catch (error) {
      console.warn("Capacitor camera rejected or unsupported, executing DOM capture input click:", error);
      // Fallback to DOM input click
      setPhotoProcessingState('idle');
      fileInputRefCamera.current?.click();
    }
  };

  const handleUploadFromLibrary = () => {
    setCapturedImagePreview(null);
    setDetectedFoodResult(null);
    fileInputRefLibrary.current?.click();
  };

  // Handle hidden file input trigger
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setPhotoProcessingState('opening_camera');
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCapturedImagePreview(reader.result);
        runPhotoInference(reader.result);
      } else {
        setPhotoProcessingState('error');
        setPhotoProcessingError("Could not read selected photo file.");
      }
    };
    reader.onerror = () => {
      setPhotoProcessingState('error');
      setPhotoProcessingError("Failed to parse the selected file.");
    };
    reader.readAsDataURL(file);
  };

  // --- LOGGING ACTION FROM MODAL ---
  const handleConfirmLogFood = () => {
    if (!session || !activeLogMealType) return;

    let foodToLog: any = null;
    let finalSource: 'USDA' | 'Open Food Facts' | 'Local DB' = 'Local DB';
    let finalConfidence = 100;

    if (detectedFoodResult) {
      foodToLog = detectedFoodResult;
      finalSource = detectedFoodResult.source || 'Local DB';
      finalConfidence = detectedFoodResult.mlConfidence || 90;
    } else if (selectedFoodItem) {
      foodToLog = selectedFoodItem;
      finalSource = selectedFoodSource;
      finalConfidence = selectedFoodConfidence;
    }

    if (!foodToLog) return;

    // Recalculate based on custom portion
    const multiplier = portionAmount / 100;
    const newLog: MealLog = {
      id: Math.random().toString(36).substr(2, 9),
      date: selectedDate,
      name: foodToLog.name,
      calories: Math.round(foodToLog.calories * multiplier),
      protein: Math.round(foodToLog.protein * multiplier * 10) / 10,
      carbs: Math.round(foodToLog.carbs * multiplier * 10) / 10,
      fat: Math.round(foodToLog.fat * multiplier * 10) / 10,
      fiber: Math.round((foodToLog.fiber || 0) * multiplier * 10) / 10,
      sugar: Math.round((foodToLog.sugar || 0) * multiplier * 10) / 10,
      sodium: Math.round((foodToLog.sodium || 0) * multiplier),
      servingAmount: portionAmount,
      mealType: activeLogMealType,
      source: finalSource,
      confidence: finalConfidence
    };

    const newLogsList = [...logs, newLog];
    saveLogs(newLogsList);

    // Reset log views states
    setActiveLogMealType(null);
    setFoodSearchQuery("");
    setLocalSearchResults([]);
    setSelectedFoodItem(null);
    setDetectedFoodResult(null);
    setCapturedImagePreview(null);
    setPhotoProcessingState('idle');
  };

  const handleSelectLocalResult = (food: FoodItem) => {
    setSelectedFoodItem(food);
    setSelectedFoodSource('Local DB');
    setSelectedFoodConfidence(100);
    setPortionAmount(100);
  };

  const handleDeleteLogItem = (id: string) => {
    const updated = logs.filter(l => l.id !== id);
    saveLogs(updated);
  };

  // --- STATS ACCUMULATION ---
  const activeDateLogs = logs.filter(l => l.date === selectedDate);
  const totalCalories = activeDateLogs.reduce((acc, curr) => acc + curr.calories, 0);
  const totalProtein = activeDateLogs.reduce((acc, curr) => acc + curr.protein, 0);
  const totalCarbs = activeDateLogs.reduce((acc, curr) => acc + curr.carbs, 0);
  const totalFat = activeDateLogs.reduce((acc, curr) => acc + curr.fat, 0);

  const burnedWorkoutCals = workoutCalories[selectedDate] || 0;
  const targetCals = session?.targetCalories || 2000;
  const remainingCals = targetCals - totalCalories + burnedWorkoutCals;

  const proteinTarget = session?.targetProtein || 150;
  const carbsTarget = session?.targetCarbs || 220;
  const fatTarget = session?.targetFat || 70;

  // Day navigation utilities
  const changeDate = (days: number) => {
    if (!selectedDate) return;
    const current = new Date(selectedDate + "T12:00:00");
    current.setDate(current.getDate() + days);
    const year = current.getFullYear();
    const month = String(current.getMonth() + 1).padStart(2, '0');
    const day = String(current.getDate()).padStart(2, '0');
    setSelectedDate(`${year}-${month}-${day}`);
  };

  const formatDisplayDate = (dateStr: string) => {
    if (!dateStr) return "";
    const [year, month, day] = dateStr.split("-").map(Number);
    const dateObj = new Date(year, month - 1, day);
    
    const today = new Date();
    if (today.getFullYear() === year && today.getMonth() === (month - 1) && today.getDate() === day) {
      return "Today";
    }
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    if (yesterday.getFullYear() === year && yesterday.getMonth() === (month - 1) && yesterday.getDate() === day) {
      return "Yesterday";
    }

    return dateObj.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
  };

  // --- AUTH SHIELDS ---
  if (!session) {
    return (
      <div className="bg-[#07070f] min-h-screen text-white font-sans flex flex-col justify-center items-center px-6 relative overflow-hidden">
        {/* Ambient Gradient Background Elements */}
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-blue-900/10 blur-[120px]" />
        <div className="absolute bottom-[-15%] right-[-10%] w-[50%] h-[50%] rounded-full bg-purple-900/10 blur-[120px]" />

        <div className="w-full max-w-md bg-[#12121c]/90 border border-gray-800 p-8 rounded-3xl shadow-2xl backdrop-blur-md relative z-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-purple-600 border border-white/10 shadow-[0_0_20px_rgba(59,130,246,0.3)] mb-4">
              <Flame className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-display font-bold tracking-tight">
              Calo<span className="text-[#3B82F6]">Flux</span>
            </h1>
            <p className="text-xs text-gray-400 mt-1 font-sans">Premium On-Device AI Nutrition Tracker</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-5">
            {authError && (
              <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-xs px-4 py-3 rounded-xl flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            {authView === 'signup' && (
              <div>
                <label className="block text-xs text-gray-400 font-medium mb-1.5 ml-1">Your Name</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-gray-500">
                    <User className="w-4 h-4" />
                  </span>
                  <input 
                    type="text" 
                    placeholder="John Doe"
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    className="w-full bg-[#07070f] border border-gray-800 focus:border-blue-500/50 rounded-xl py-3 pl-10 pr-4 text-sm text-white placeholder-gray-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs text-gray-400 font-medium mb-1.5 ml-1">Email Address</label>
              <div className="relative">
                <span className="absolute left-3.5 top-3.5 text-gray-500">@</span>
                <input 
                  type="email" 
                  placeholder="name@example.com"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  className="w-full bg-[#07070f] border border-gray-800 focus:border-blue-500/50 rounded-xl py-3 pl-10 pr-4 text-sm text-white placeholder-gray-600 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-gray-400 font-medium mb-1.5 ml-1">Secret Password</label>
              <div className="relative">
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3.5 text-gray-500 hover:text-gray-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <input 
                  type={showPassword ? "text" : "password"} 
                  placeholder="••••••••"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className="w-full bg-[#07070f] border border-gray-800 focus:border-blue-500/50 rounded-xl py-3 px-4 pr-11 text-sm text-white placeholder-gray-600 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium rounded-xl py-3 text-sm shadow-[0_4px_15px_rgba(59,130,246,0.25)] transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
            >
              {authView === 'signup' ? 'Create Premium Account' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center text-xs text-gray-400">
            {authView === 'login' ? (
              <p>
                New to CaloFlux?{" "}
                <button 
                  type="button" 
                  onClick={() => { setAuthView('signup'); setAuthError(""); }}
                  className="text-blue-400 font-semibold hover:underline cursor-pointer"
                >
                  Create Account
                </button>
              </p>
            ) : (
              <p>
                Already have an account?{" "}
                <button 
                  type="button" 
                  onClick={() => { setAuthView('login'); setAuthError(""); }}
                  className="text-blue-400 font-semibold hover:underline cursor-pointer"
                >
                  Sign In
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  // --- ONBOARDING FLOW VIEW ---
  if (!session.onboarded) {
    return (
      <div className="bg-[#07070f] min-h-screen text-white font-sans flex flex-col items-center justify-center px-6 py-12 relative overflow-hidden">
        {/* Ambient background decoration */}
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-blue-900/10 blur-[120px]" />
        <div className="absolute bottom-[-15%] right-[-10%] w-[50%] h-[50%] rounded-full bg-purple-900/10 blur-[120px]" />

        <div className="w-full max-w-lg bg-[#12121c]/90 border border-gray-800 p-8 rounded-3xl shadow-2xl backdrop-blur-md relative z-10">
          
          {/* Header Progress indicator */}
          <div className="flex items-center justify-between mb-8">
            <span className="text-xs font-mono text-blue-400 tracking-wider">ONBOARDING PROFILE</span>
            <div className="flex gap-1.5">
              {[1, 2, 3, 4].map(step => (
                <div 
                  key={step} 
                  className={`w-8 h-1 rounded-full transition-all duration-300 ${onboardingStep >= step ? 'bg-blue-500' : 'bg-gray-850/40'}`} 
                />
              ))}
            </div>
          </div>

          <AnimatePresence mode="wait">
            {onboardingStep === 1 && (
              <motion.div 
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-display font-bold">Personal Metrics</h2>
                  <p className="text-xs text-gray-400 mt-1">First, let's establish your physiological statistics to formulate targets.</p>
                </div>

                <div className="space-y-4">
                  {/* Gender */}
                  <div>
                    <label className="block text-xs text-gray-400 font-medium mb-2 ml-1">Biological Gender</label>
                    <div className="grid grid-cols-3 gap-3">
                      {(['male', 'female', 'other'] as const).map(g => (
                        <button
                           key={g}
                           type="button"
                           onClick={() => setGender(g)}
                           className={`py-3 rounded-xl text-sm font-medium border transition-all capitalize cursor-pointer ${gender === g ? 'bg-blue-600/20 border-blue-500 text-white shadow-[0_0_15px_rgba(59,130,246,0.15)]' : 'bg-[#07070f] border-gray-800 text-gray-400 hover:border-gray-750'}`}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Age */}
                  <div>
                    <div className="flex justify-between items-center mb-1 ml-1">
                      <label className="text-xs text-gray-400 font-medium">Age</label>
                      <span className="text-sm font-display font-semibold text-blue-400">{age} years old</span>
                    </div>
                    <input 
                      type="range" 
                      min="12" 
                      max="90" 
                      value={age}
                      onChange={(e) => setAge(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                  </div>

                  {/* Height */}
                  <div>
                    <div className="flex justify-between items-center mb-1 ml-1">
                      <label className="text-xs text-gray-400 font-medium">Height</label>
                      <span className="text-sm font-display font-semibold text-blue-400">{height} cm <span className="text-gray-500 font-sans text-xs">({Math.round(height * 0.393701)} in)</span></span>
                    </div>
                    <input 
                      type="range" 
                      min="100" 
                      max="220" 
                      value={height}
                      onChange={(e) => setHeight(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                  </div>

                  {/* Weight */}
                  <div>
                    <div className="flex justify-between items-center mb-1 ml-1">
                      <label className="text-xs text-gray-400 font-medium">Weight</label>
                      <span className="text-sm font-display font-semibold text-blue-400">{weight} kg <span className="text-gray-500 font-sans text-xs">({Math.round(weight * 2.20462)} lbs)</span></span>
                    </div>
                    <input 
                      type="range" 
                      min="35" 
                      max="180" 
                      value={weight}
                      onChange={(e) => setWeight(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="button"
                    onClick={() => setOnboardingStep(2)}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium py-3 rounded-xl text-sm transition-all cursor-pointer shadow-lg"
                  >
                    Continue
                  </button>
                </div>
              </motion.div>
            )}

            {onboardingStep === 2 && (
              <motion.div 
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-display font-bold">What is your Target Goal?</h2>
                  <p className="text-xs text-gray-400 mt-1">This dynamically shifts target calorie limits and protein distributions.</p>
                </div>

                <div className="space-y-3.5">
                  {[
                    { key: 'lose', label: 'Lose Weight', desc: 'Sustained caloric deficit (TDEE - 500 kcal) with increased protein ratios to secure lean muscle retention.' },
                    { key: 'maintain', label: 'Maintain Weight', desc: 'Balanced baseline nutrition matching daily thermal output exactly to stay athletic and sharp.' },
                    { key: 'gain', label: 'Gain Muscle', desc: 'Controlled clean caloric surplus (TDEE + 500 kcal) paired with abundant carbohydrates for glycogen loading.' }
                  ].map(item => (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setGoal(item.key as any)}
                      className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-4 cursor-pointer ${goal === item.key ? 'bg-blue-600/10 border-blue-500' : 'bg-[#07070f] border-gray-800 hover:border-gray-750'}`}
                    >
                      <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${goal === item.key ? 'border-blue-500 bg-blue-600' : 'border-gray-700'}`}>
                        {goal === item.key && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-white">{item.label}</h4>
                        <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">{item.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setOnboardingStep(1)}
                    className="bg-gray-800/40 hover:bg-gray-800 border border-gray-800 text-gray-300 font-medium py-3 rounded-xl text-sm transition-all text-center cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setOnboardingStep(3)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium py-3 rounded-xl text-sm transition-all text-center cursor-pointer shadow-lg"
                  >
                    Continue
                  </button>
                </div>
              </motion.div>
            )}

            {onboardingStep === 3 && (
              <motion.div 
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-display font-bold">Physical Activity Level</h2>
                  <p className="text-xs text-gray-400 mt-1">Estimating the physical coefficient of non-workout thermal burn.</p>
                </div>

                <div className="space-y-3.5">
                  {[
                    { key: 'sedentary', label: 'Sedentary (Desk Job)', desc: 'Spend most of your day sitting down, minimal sports, desk-bound lifestyle.' },
                    { key: 'light', label: 'Lightly Active', desc: 'Occasional light walks, active chores, or casual sports 1-3 times a week.' },
                    { key: 'moderate', label: 'Moderately Active', desc: 'Standard workouts, jogging, gym or athletic active sessions 3-5 times a week.' },
                    { key: 'active', label: 'Very Active', desc: 'Intense bodybuilding, professional sports, or strenuous manual labor 6-7 days a week.' }
                  ].map(item => (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => setActivityLevel(item.key as any)}
                      className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-4 cursor-pointer ${activityLevel === item.key ? 'bg-blue-600/10 border-blue-500' : 'bg-[#07070f] border-gray-800 hover:border-gray-750'}`}
                    >
                      <div className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${activityLevel === item.key ? 'border-blue-500 bg-blue-600' : 'border-gray-700'}`}>
                        {activityLevel === item.key && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-white">{item.label}</h4>
                        <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">{item.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setOnboardingStep(2)}
                    className="bg-gray-800/40 hover:bg-gray-800 border border-gray-800 text-gray-300 font-medium py-3 rounded-xl text-sm transition-all text-center cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setOnboardingStep(4)}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium py-3 rounded-xl text-sm transition-all text-center cursor-pointer shadow-lg"
                  >
                    Calculate Targets
                  </button>
                </div>
              </motion.div>
            )}

            {onboardingStep === 4 && (
              <motion.div 
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-display font-bold">Your Custom CaloFlux Plan</h2>
                  <p className="text-xs text-gray-400 mt-1">Here is the algorithmic output of your calculated energy and metabolic blueprint.</p>
                </div>

                {/* Calculated statistics boxes */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-[#07070f] border border-gray-800 p-4 rounded-2xl">
                    <span className="text-[10px] font-mono text-gray-500 block">BODY MASS INDEX (BMI)</span>
                    <span className="text-xl font-display font-bold mt-1 block">
                      {(weight / ((height / 100) ** 2)).toFixed(1)}
                    </span>
                    <span className="text-[10px] text-blue-400 block mt-1">
                      {(() => {
                        const bmi = weight / ((height / 100) ** 2);
                        if (bmi < 18.5) return "Underweight (Need nutrient density)";
                        if (bmi < 25) return "Normal / Athletic Baseline";
                        if (bmi < 30) return "Slight Overweight Range";
                        return "Obese Range (Deficit recommended)";
                      })()}
                    </span>
                  </div>

                  <div className="bg-[#07070f] border border-gray-800 p-4 rounded-2xl">
                    <span className="text-[10px] font-mono text-gray-500 block">TOTAL DAILY EXPENDITURE (TDEE)</span>
                    <span className="text-xl font-display font-bold mt-1 block">
                      {handleCalculateTDEE(weight, height, age, gender, activityLevel)}
                    </span>
                    <span className="text-[10px] text-blue-400 block mt-1">Estimated total calorie burn / day</span>
                  </div>
                </div>

                {/* Target Calorie Block */}
                <div className="bg-blue-950/20 border border-blue-500/20 p-5 rounded-2xl text-center">
                  <span className="text-xs font-mono text-blue-300">CALORIC INTAKE TARGET</span>
                  <span className="text-3xl font-display font-bold text-white block mt-1.5">
                    {(() => {
                      const tdee = handleCalculateTDEE(weight, height, age, gender, activityLevel);
                      return goal === 'lose' ? tdee - 500 : goal === 'gain' ? tdee + 500 : tdee;
                    })()} <span className="text-sm font-sans text-gray-400">kcal / day</span>
                  </span>
                  <p className="text-[10px] text-gray-400 mt-2 leading-relaxed">
                    {goal === 'lose' 
                      ? 'Caloric deficit of -500 kcal programmed. Est. weekly weight loss: ~0.5kg.' 
                      : goal === 'gain' 
                      ? 'Caloric surplus of +500 kcal programmed. Optimal for myofibrillar hypertrophy.' 
                      : 'Baseline maintenance target programmed to secure energy equilibrium.'
                    }
                  </p>
                </div>

                {/* Target Macros breakdown */}
                <div>
                  <span className="text-xs font-mono text-gray-400 block mb-3">MATRIC METRIC MACRONUTRIENT DISTRIBUTION</span>
                  
                  {(() => {
                    const tdee = handleCalculateTDEE(weight, height, age, gender, activityLevel);
                    const targetCals = goal === 'lose' ? tdee - 500 : goal === 'gain' ? tdee + 500 : tdee;
                    let pPct = 0.30, cPct = 0.40, fPct = 0.30;
                    if (goal === 'lose') { pPct = 0.35; cPct = 0.35; fPct = 0.30; }
                    else if (goal === 'gain') { pPct = 0.25; cPct = 0.50; fPct = 0.25; }

                    const targetP = Math.round((targetCals * pPct) / 4);
                    const targetC = Math.round((targetCals * cPct) / 4);
                    const targetF = Math.round((targetCals * fPct) / 9);

                    return (
                      <div className="space-y-3">
                        {/* Protein */}
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-semibold text-gray-300">Protein ({Math.round(pPct * 100)}%)</span>
                            <span className="font-mono text-blue-400">{targetP}g / {targetP * 4} kcal</span>
                          </div>
                          <div className="w-full h-1.5 bg-gray-800/40 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500" style={{ width: `${pPct * 100}%` }} />
                          </div>
                        </div>

                        {/* Carbs */}
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-semibold text-gray-300">Carbohydrates ({Math.round(cPct * 100)}%)</span>
                            <span className="font-mono text-purple-400">{targetC}g / {targetC * 4} kcal</span>
                          </div>
                          <div className="w-full h-1.5 bg-gray-800/40 rounded-full overflow-hidden">
                            <div className="h-full bg-purple-500" style={{ width: `${cPct * 100}%` }} />
                          </div>
                        </div>

                        {/* Fat */}
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-semibold text-gray-300">Lipid Fats ({Math.round(fPct * 100)}%)</span>
                            <span className="font-mono text-orange-400">{targetF}g / {targetF * 9} kcal</span>
                          </div>
                          <div className="w-full h-1.5 bg-gray-800/40 rounded-full overflow-hidden">
                            <div className="h-full bg-orange-500" style={{ width: `${fPct * 100}%` }} />
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                <div className="grid grid-cols-2 gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setOnboardingStep(3)}
                    className="bg-gray-800/40 hover:bg-gray-800 border border-gray-800 text-gray-300 font-medium py-3 rounded-xl text-sm transition-all text-center cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={saveOnboarding}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-medium py-3 rounded-xl text-sm shadow-[0_0_20px_rgba(59,130,246,0.25)] transition-all text-center flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Check className="w-4 h-4" /> Begin My Journey
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
      </div>
    );
  }

  // --- MAIN APPLICATION CORE VIEW ---
  return (
    <div className="bg-[#07070f] min-h-screen text-white font-sans flex flex-col pb-24 relative overflow-x-hidden">
      
      {/* Hidden file selectors for photo log feature */}
      <input 
        type="file" 
        accept="image/*" 
        capture="environment" 
        ref={fileInputRefCamera}
        onChange={handleFileInputChange}
        className="hidden" 
      />
      <input 
        type="file" 
        accept="image/*" 
        ref={fileInputRefLibrary}
        onChange={handleFileInputChange}
        className="hidden" 
      />

      {/* --- UPPER NAVBAR HEADER --- */}
      <header className="px-6 pt-5 pb-4 border-b border-gray-800/50 flex justify-between items-center bg-[#07070f]/90 backdrop-blur-md sticky top-0 z-40">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center">
              <Flame className="w-4 h-4 text-white" />
            </div>
            <span className="text-base font-display font-bold tracking-tight">Calo<span className="text-[#3B82F6]">Flux</span></span>
            <span className="text-[10px] bg-blue-500/15 text-blue-400 px-1.5 py-0.5 rounded font-mono">Premium</span>
          </div>
        </div>

        {/* Date Selector component */}
        <div className="flex items-center gap-2 bg-[#12121c]/85 border border-gray-800 px-3 py-1.5 rounded-xl shadow-md">
          <button 
            onClick={() => changeDate(-1)}
            className="text-slate-400 hover:text-white p-1"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-semibold select-none min-w-[100px] text-center">
            {formatDisplayDate(selectedDate)}
          </span>
          <button 
            onClick={() => changeDate(1)}
            className="text-slate-400 hover:text-white p-1"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* --- SCROLLABLE CONTAINER VIEW --- */}
      <main className="px-5 pt-5 max-w-lg mx-auto w-full flex-grow">

        {/* --- TAB 1: DASHBOARD --- */}
        {currentTab === 'dashboard' && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Calorie Progress Ring and Target Panel */}
            <div className="bg-[#12121c] border border-gray-800 p-6 rounded-3xl flex items-center justify-between gap-6 relative overflow-hidden shadow-xl">
              <div className="absolute top-[-10px] left-[-10px] w-24 h-24 bg-blue-600/5 rounded-full blur-[40px]" />
              
              <div className="space-y-4 shrink-0">
                <div>
                  <span className="text-[10px] font-mono text-gray-500 block uppercase tracking-wider">Target Calories</span>
                  <span className="text-2xl font-display font-bold">{targetCals} <span className="text-xs font-sans text-gray-400">kcal</span></span>
                </div>
                
                <div>
                  <span className="text-[10px] font-mono text-gray-500 block uppercase tracking-wider">Consumed</span>
                  <span className="text-xl font-display font-semibold text-blue-400">{totalCalories} <span className="text-xs font-sans text-gray-400">kcal</span></span>
                </div>

                <div>
                  <span className="text-[10px] font-mono text-gray-500 block uppercase tracking-wider">Burned (Workouts)</span>
                  <span className="text-xl font-display font-semibold text-emerald-400">+{burnedWorkoutCals} <span className="text-xs font-sans text-gray-400">kcal</span></span>
                </div>
              </div>

              {/* SVG Radial Calorie Ring */}
              <div className="relative w-36 h-36 flex items-center justify-center">
                {/* Background Track */}
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="72"
                    cy="72"
                    r="58"
                    className="stroke-[#07070f] fill-none"
                    strokeWidth="12"
                  />
                  {/* Progress Indicator */}
                  <circle
                    cx="72"
                    cy="72"
                    r="58"
                    className="stroke-blue-500 fill-none transition-all duration-500"
                    strokeWidth="12"
                    strokeDasharray={2 * Math.PI * 58}
                    strokeDashoffset={(2 * Math.PI * 58) * (1 - Math.min(1, totalCalories / (targetCals + burnedWorkoutCals)))}
                    strokeLinecap="round"
                    style={{
                      filter: 'drop-shadow(0 0 6px rgba(59, 130, 246, 0.45))'
                    }}
                  />
                </svg>

                {/* Internal numbers */}
                <div className="absolute text-center">
                  <span className="text-2xl font-display font-bold block leading-none">
                    {remainingCals >= 0 ? remainingCals : Math.abs(remainingCals)}
                  </span>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block mt-1">
                    {remainingCals >= 0 ? 'kcal left' : 'kcal over'}
                  </span>
                </div>
              </div>
            </div>

            {/* Macro targets progress section */}
            <div className="bg-[#12121c] border border-gray-800 p-5 rounded-3xl space-y-4 shadow-xl">
              <span className="text-xs font-mono text-gray-400 block tracking-wider uppercase">Macronutrient Distribution Today</span>
              
              <div className="grid grid-cols-3 gap-4">
                {/* Protein progress */}
                <div className="bg-[#07070f] border border-gray-800/80 p-3.5 rounded-2xl relative">
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-[10px] font-mono text-gray-400 uppercase">Protein</span>
                    <span className="font-mono text-blue-400 font-bold">{Math.round(totalProtein)}g</span>
                  </div>
                  <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden mb-1.5">
                    <div 
                      className="h-full bg-blue-500 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, (totalProtein / proteinTarget) * 100)}%` }}
                    />
                  </div>
                  <span className="text-[9px] text-gray-500">Target: {proteinTarget}g</span>
                </div>

                {/* Carbs progress */}
                <div className="bg-[#07070f] border border-gray-800/80 p-3.5 rounded-2xl relative">
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-[10px] font-mono text-gray-400 uppercase">Carbs</span>
                    <span className="font-mono text-purple-400 font-bold">{Math.round(totalCarbs)}g</span>
                  </div>
                  <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden mb-1.5">
                    <div 
                      className="h-full bg-purple-500 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, (totalCarbs / carbsTarget) * 100)}%` }}
                    />
                  </div>
                  <span className="text-[9px] text-gray-500">Target: {carbsTarget}g</span>
                </div>

                {/* Fat progress */}
                <div className="bg-[#07070f] border border-gray-800/80 p-3.5 rounded-2xl relative">
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="text-[10px] font-mono text-gray-400 uppercase">Fat</span>
                    <span className="font-mono text-orange-400 font-bold">{Math.round(totalFat)}g</span>
                  </div>
                  <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden mb-1.5">
                    <div 
                      className="h-full bg-orange-500 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, (totalFat / fatTarget) * 100)}%` }}
                    />
                  </div>
                  <span className="text-[9px] text-gray-500">Target: {fatTarget}g</span>
                </div>
              </div>
            </div>

            {/* Bottom Row - Water Tracker & Burn activity logs */}
            <div className="grid grid-cols-2 gap-4">
              
              {/* Hydration tracker */}
              <div className="bg-[#12121c] border border-gray-800 p-5 rounded-3xl flex flex-col justify-between shadow-xl">
                <div>
                  <div className="flex items-center gap-2 text-gray-400 mb-2">
                    <Droplet className="w-4 h-4 text-sky-450" />
                    <span className="text-xs font-mono uppercase tracking-wider">Hydration</span>
                  </div>
                  <span className="text-2xl font-display font-bold">
                    {waterIntake[selectedDate] || 0} <span className="text-xs font-sans text-gray-400">Cups</span>
                  </span>
                  <span className="text-[9px] text-gray-500 block mt-0.5">Recommended: 8 Cups</span>
                </div>

                {/* Water log row controls */}
                <div className="flex items-center justify-between gap-3 mt-4">
                  <button
                    onClick={() => adjustWater(-1)}
                    className="w-10 h-10 rounded-xl bg-[#07070f] border border-gray-800 flex items-center justify-center hover:bg-[#12121c] hover:border-gray-750 transition-colors cursor-pointer"
                  >
                    <Minus className="w-4 h-4 text-gray-300" />
                  </button>
                  <div className="flex gap-0.5 select-none text-sky-400 shrink-0">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <span 
                        key={i} 
                        className={`text-sm ${i < (waterIntake[selectedDate] || 0) ? 'opacity-100' : 'opacity-20'}`}
                      >
                        💧
                      </span>
                    ))}
                  </div>
                  <button
                    onClick={() => adjustWater(1)}
                    className="w-10 h-10 rounded-xl bg-[#07070f] border border-gray-800 flex items-center justify-center hover:bg-[#12121c] hover:border-gray-750 transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4 text-gray-300" />
                  </button>
                </div>
              </div>

              {/* Burn / Workout tracking panel */}
              <div className="bg-[#12121c] border border-gray-800 p-5 rounded-3xl flex flex-col justify-between shadow-xl">
                <div>
                  <div className="flex items-center gap-2 text-gray-400 mb-2">
                    <Dumbbell className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-mono uppercase tracking-wider">Workouts</span>
                  </div>
                  <span className="text-2xl font-display font-bold">
                    {burnedWorkoutCals} <span className="text-xs font-sans text-gray-400">kcal</span>
                  </span>
                  <span className="text-[9px] text-gray-500 block mt-0.5">Increases target limits</span>
                </div>

                <div className="mt-4">
                  <button
                    onClick={() => setShowWorkoutModal(true)}
                    className="w-full bg-[#07070f] border border-gray-800 hover:bg-[#12121c] hover:border-gray-750 text-xs font-medium py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <Plus className="w-3.5 h-3.5 text-gray-400" /> Log Exercise
                  </button>
                </div>
              </div>

            </div>

            {/* General tips banner */}
            <div className="bg-[#07070f] border border-gray-800 p-4 rounded-2xl flex gap-3 items-start">
              <Sparkles className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-semibold">CaloFlux Smart Suggestion</h4>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-0.5">
                  Based on your onboarding target, consume protein sources such as <b>Chicken Breast</b> or <b>Eggs</b>. Use the Log tab to snap a photo of your meal and let the AI instantly classify and load the nutritional breakdown.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* --- TAB 2: LOG TAB --- */}
        {currentTab === 'log' && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-5"
          >
            {/* Meal Categories breakdown */}
            {(['Breakfast', 'Lunch', 'Dinner', 'Snacks'] as const).map(mType => {
              const categoryLogs = activeDateLogs.filter(l => l.mealType === mType);
              const categoryCals = categoryLogs.reduce((sum, item) => sum + item.calories, 0);

              return (
                <div key={mType} className="bg-[#12121c] border border-gray-800 p-4.5 rounded-2xl shadow-md">
                  
                  {/* Category Header */}
                  <div className="flex justify-between items-center border-b border-gray-800/60 pb-3 mb-3">
                    <div>
                      <h3 className="text-sm font-semibold font-display tracking-tight text-white">{mType}</h3>
                      <span className="text-[10px] text-gray-400 block font-mono">Consumed: {categoryCals} kcal</span>
                    </div>
                    
                    <button
                      onClick={() => setActiveLogMealType(mType)}
                      className="bg-blue-600/10 hover:bg-blue-600/20 border border-gray-850 text-blue-400 hover:text-blue-300 text-xs px-3 py-1.5 rounded-xl transition-all flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Food
                    </button>
                  </div>

                  {/* Logged Category Foods list */}
                  {categoryLogs.length === 0 ? (
                    <div className="text-center py-4 text-slate-600 text-xs italic">
                      No items logged for {mType.toLowerCase()} today.
                    </div>
                  ) : (
                    <div className="space-y-3.5">
                      {categoryLogs.map(item => (
                        <div key={item.id} className="flex justify-between items-center gap-3 py-1">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-medium text-slate-200">{item.name}</span>
                              
                              {/* Source badge color selector */}
                              <span className={`text-[8px] font-mono font-bold uppercase px-1 py-0.5 rounded ${
                                item.source === 'USDA' 
                                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' 
                                  : item.source === 'Open Food Facts'
                                  ? 'bg-orange-500/15 text-orange-400 border border-orange-500/20'
                                  : 'bg-slate-500/15 text-slate-400 border border-slate-500/20'
                              }`}>
                                {item.source}
                              </span>

                              {item.confidence && item.confidence < 100 && (
                                <span className="text-[8px] text-slate-500 font-mono">({item.confidence}% matching)</span>
                              )}
                            </div>
                            <div className="flex gap-2 text-[10px] text-slate-400">
                              <span>Portion: {item.servingAmount}g</span>
                              <span>P: {Math.round(item.protein)}g</span>
                              <span>C: {Math.round(item.carbs)}g</span>
                              <span>F: {Math.round(item.fat)}g</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="text-xs font-semibold text-white font-mono">{item.calories} kcal</span>
                            <button
                              onClick={() => handleDeleteLogItem(item.id)}
                              className="text-red-500/70 hover:text-red-400 p-1 text-[10px] font-medium hover:underline"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                </div>
              );
            })}
          </motion.div>
        )}

        {/* --- TAB 3: PROFILE TAB --- */}
        {currentTab === 'profile' && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Header profile details info card */}
            <div className="bg-[#12121c] border border-gray-800 p-6 rounded-3xl relative overflow-hidden flex items-center gap-4 shadow-xl">
              <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center font-display font-bold text-2xl shadow-[0_0_15px_rgba(59,130,246,0.3)]">
                {session.name.charAt(0).toUpperCase()}
              </div>
              <div className="space-y-0.5">
                <h2 className="text-lg font-display font-bold text-white">{session.name}</h2>
                <span className="text-xs text-gray-400 block">{session.email}</span>
                <span className="text-[10px] text-blue-400 font-semibold block uppercase font-mono tracking-wider">
                  Goal: {session.goal === 'lose' ? 'Caloric Deficit (Weight Loss)' : session.goal === 'gain' ? 'Caloric Surplus (Muscle Mass)' : 'Maintenance Balance'}
                </span>
              </div>
            </div>

            {/* Editable metrics fields lists */}
            <div className="bg-[#12121c] border border-gray-800 p-5 rounded-3xl space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-gray-800/60 pb-3">
                <span className="text-xs font-mono text-gray-400 uppercase tracking-wider">Current Physiological Metrics</span>
                <button
                  onClick={() => setOnboardingStep(1)} // Reset onboarding profile to start
                  className="text-[10px] text-blue-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" /> Recalculate TDEE / Re-Onboard
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#07070f] p-3 rounded-xl border border-gray-800">
                  <span className="text-[10px] text-gray-500 block font-mono uppercase">Height</span>
                  <span className="text-sm font-semibold font-display mt-0.5 block text-white">{session.height} cm</span>
                </div>
                <div className="bg-[#07070f] p-3 rounded-xl border border-gray-800">
                  <span className="text-[10px] text-gray-500 block font-mono uppercase">Weight</span>
                  <span className="text-sm font-semibold font-display mt-0.5 block text-white">{session.weight} kg</span>
                </div>
                <div className="bg-[#07070f] p-3 rounded-xl border border-gray-800">
                  <span className="text-[10px] text-gray-500 block font-mono uppercase">Age</span>
                  <span className="text-sm font-semibold font-display mt-0.5 block text-white">{session.age} years</span>
                </div>
                <div className="bg-[#07070f] p-3 rounded-xl border border-gray-800">
                  <span className="text-[10px] text-gray-500 block font-mono uppercase">Activity Level</span>
                  <span className="text-sm font-semibold font-display mt-0.5 block capitalize text-white">{session.activityLevel}</span>
                </div>
              </div>
            </div>

            {/* Custom Target limits overrides */}
            <div className="bg-[#12121c] border border-gray-800 p-5 rounded-3xl space-y-4 shadow-xl">
              <span className="text-xs font-mono text-gray-400 block tracking-wider uppercase">CaloFlux Programmed Targets</span>

              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Daily Calories Target</span>
                  <span className="font-mono font-semibold text-white">{session.targetCalories} kcal</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Daily Protein Target</span>
                  <span className="font-mono font-semibold text-blue-400">{session.targetProtein}g</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Daily Carbs Target</span>
                  <span className="font-mono font-semibold text-purple-400">{session.targetCarbs}g</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400">Daily Lipid Fat Target</span>
                  <span className="font-mono font-semibold text-orange-400">{session.targetFat}g</span>
                </div>
              </div>
            </div>

            {/* Account controls actions */}
            <div className="space-y-3.5">
              <button
                onClick={() => {
                  if (confirm("Are you sure you want to clear your today logs? This is irreversible.")) {
                    saveLogs([]);
                    saveWater({});
                    saveWorkouts({});
                    alert("App log data successfully wiped clean.");
                  }
                }}
                className="w-full bg-red-500/10 hover:bg-red-500/25 text-red-400 border border-red-500/20 text-xs font-medium py-3 rounded-xl transition-all text-center cursor-pointer"
              >
                Wipe Local Logs & Reset Metrics
              </button>

              <button
                onClick={handleLogout}
                className="w-full bg-[#12121c] border border-gray-800 hover:bg-[#1b1b28] text-gray-300 text-xs font-medium py-3 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <LogOut className="w-4 h-4 text-gray-400" /> Log Out CaloFlux Session
              </button>
            </div>
          </motion.div>
        )}

      </main>

      {/* --- TAB-BAR iOS FIXED FOOTER NAVIGATION --- */}
      <footer className="fixed bottom-0 left-0 right-0 h-20 bg-[#07070f]/95 border-t border-gray-800/60 backdrop-blur-md z-40 flex items-center justify-around px-6 max-w-lg mx-auto shadow-[0_-4px_12px_rgba(0,0,0,0.5)]">
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`flex flex-col items-center justify-center gap-1.5 transition-all py-1 px-3 rounded-xl cursor-pointer ${currentTab === 'dashboard' ? 'text-blue-400 font-semibold' : 'text-gray-500 hover:text-gray-300'}`}
        >
          <Activity className="w-5 h-5" />
          <span className="text-[10px]">Dashboard</span>
        </button>

        <button
          onClick={() => setCurrentTab('log')}
          className={`flex flex-col items-center justify-center gap-1.5 transition-all py-1 px-3 rounded-xl cursor-pointer ${currentTab === 'log' ? 'text-blue-400 font-semibold' : 'text-gray-500 hover:text-gray-300'}`}
        >
          <Calendar className="w-5 h-5" />
          <span className="text-[10px]">Log Tab</span>
        </button>

        <button
          onClick={() => setCurrentTab('profile')}
          className={`flex flex-col items-center justify-center gap-1.5 transition-all py-1 px-3 rounded-xl cursor-pointer ${currentTab === 'profile' ? 'text-blue-400 font-semibold' : 'text-gray-500 hover:text-gray-300'}`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px]">Profile</span>
        </button>
      </footer>

      {/* --- MODAL 1: ADD / SCAN FOOD LOG OVERLAY --- */}
      <AnimatePresence>
        {activeLogMealType && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#000000]/80 z-50 backdrop-blur-sm flex flex-col justify-end max-w-lg mx-auto"
          >
            {/* Modal Body Card */}
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25 }}
              className="bg-[#0c0c14] border-t border-gray-800 rounded-t-[32px] max-h-[88vh] overflow-y-auto flex flex-col p-6 shadow-2xl"
            >
              
              {/* Modal Header */}
              <div className="flex justify-between items-center mb-5 shrink-0">
                <div>
                  <span className="text-[10px] font-mono text-blue-400 tracking-wider block">CALOFLUX SMART RECOGNITION</span>
                  <h3 className="text-base font-display font-bold text-white">Add to {activeLogMealType}</h3>
                </div>
                <button
                  onClick={() => {
                    setActiveLogMealType(null);
                    setFoodSearchQuery("");
                    setLocalSearchResults([]);
                    setSelectedFoodItem(null);
                    setDetectedFoodResult(null);
                    setCapturedImagePreview(null);
                    setPhotoProcessingState('idle');
                  }}
                  className="bg-[#12121c] border border-gray-800 text-gray-400 hover:text-white px-3.5 py-1.5 rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>

              {/* Photo Scanning Pipeline Box */}
              <div className="bg-[#12121c] border border-gray-850 p-4.5 rounded-2xl mb-5 space-y-4 shadow-inner">
                <div className="flex items-center gap-2">
                  <Camera className="w-4.5 h-4.5 text-blue-400" />
                  <span className="text-xs font-mono uppercase tracking-wider text-gray-300">Photo Nutrition Scanner</span>
                  
                  {modelLoadingState === 'loading' && (
                    <span className="text-[9px] text-amber-400 font-mono flex items-center gap-1 ml-auto">
                      <Loader2 className="w-3 h-3 animate-spin" /> Setup: loading TF model...
                    </span>
                  )}
                  {modelLoadingState === 'ready' && (
                    <span className="text-[9px] text-emerald-400 font-mono ml-auto">
                      ● AI scanner cached & active
                    </span>
                  )}
                </div>

                {/* Main Scanning Action Buttons Row */}
                {photoProcessingState === 'idle' && (
                  <div className="grid grid-cols-2 gap-3.5">
                    <button
                      type="button"
                      onClick={handleTakePhotoNative}
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-semibold py-3.5 px-4 rounded-xl text-xs flex flex-col items-center justify-center gap-1.5 transition-all shadow-[0_4px_15px_rgba(59,130,246,0.2)] cursor-pointer"
                    >
                      <Camera className="w-5 h-5 shrink-0" />
                      Take Photo
                    </button>
                    <button
                      type="button"
                      onClick={handleUploadFromLibrary}
                      className="bg-[#07070f] border border-gray-800 hover:bg-[#12121c] text-gray-300 hover:text-white font-semibold py-3.5 px-4 rounded-xl text-xs flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Smartphone className="w-5 h-5 shrink-0 text-gray-400" />
                      Upload from Library
                    </button>
                  </div>
                )}

                {/* ACTIVE RUNNING PICTURE ANALYSIS DISPLAY */}
                {photoProcessingState !== 'idle' && (
                  <div className="space-y-4">
                    
                    {/* Picture preview thumbnail */}
                    {capturedImagePreview && (
                      <div className="relative w-full max-w-[200px] h-[150px] mx-auto rounded-2xl overflow-hidden border border-gray-800 shadow-lg bg-black flex items-center justify-center">
                        <img 
                          src={capturedImagePreview} 
                          alt="Food Preview"
                          className="w-full h-full object-cover" 
                        />
                        
                        {/* SCROLLING SCANNING BAR INDICATOR OVERLAY */}
                        {(photoProcessingState === 'opening_camera' || photoProcessingState === 'analyzing' || photoProcessingState === 'looking_up') && (
                          <div className="absolute inset-0 bg-blue-500/10 pointer-events-none overflow-hidden flex flex-col justify-start">
                            <motion.div 
                              initial={{ y: "-100%" }}
                              animate={{ y: "200%" }}
                              transition={{ repeat: Infinity, duration: 1.8, ease: "linear" }}
                              className="h-1 bg-blue-400 shadow-[0_0_12px_#3b82f6] w-full"
                            />
                          </div>
                        )}
                      </div>
                    )}

                    {/* Status Log loader */}
                    <div className="text-center py-2">
                      {photoProcessingState === 'opening_camera' && (
                        <span className="text-xs text-gray-400 flex items-center justify-center gap-2 font-medium">
                          <Loader2 className="w-4 h-4 animate-spin text-blue-400" /> Loading captured image...
                        </span>
                      )}
                      {photoProcessingState === 'analyzing' && (
                        <div className="space-y-1">
                          <span className="text-xs text-blue-400 flex items-center justify-center gap-2 font-medium">
                            <Loader2 className="w-4 h-4 animate-spin" /> Analyzing pixel patterns...
                          </span>
                           <span className="text-[9px] text-gray-500 block font-mono">Running Local TensorFlow food classification model</span>
                        </div>
                      )}
                      {photoProcessingState === 'looking_up' && (
                        <div className="space-y-1">
                          <span className="text-xs text-orange-400 flex items-center justify-center gap-2 font-medium">
                            <Loader2 className="w-4 h-4 animate-spin text-orange-400" /> Connecting to USDA FoodData Central...
                          </span>
                          <span className="text-[9px] text-gray-500 block font-mono">Waterfall Search: USDA FoodData (DEMO_KEY) → Open Food Facts</span>
                        </div>
                      )}
                      {photoProcessingState === 'error' && (
                        <div className="space-y-2">
                          <span className="text-xs text-red-400 flex items-center justify-center gap-2 font-medium">
                            <AlertTriangle className="w-4 h-4 shrink-0" /> {photoProcessingError}
                          </span>
                          <button
                            type="button"
                            onClick={() => setPhotoProcessingState('idle')}
                            className="bg-gray-900 hover:bg-gray-850 border border-gray-800 text-xs px-3 py-1.5 rounded-xl transition-all cursor-pointer text-white"
                          >
                            Reset Scanner
                          </button>
                        </div>
                      )}
                    </div>

                  </div>
                )}

              </div>

              {/* SEARCH ENGINE SECTION (If no photo is processing) */}
              {(photoProcessingState === 'idle' || photoProcessingState === 'error') && !detectedFoodResult && !selectedFoodItem && (
                <div className="space-y-4">
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-gray-500">
                      <Search className="w-4.5 h-4.5" />
                    </span>
                    <input 
                      type="text"
                      placeholder="Search 200+ local foods (e.g. Avocado, Pizza)..."
                      value={foodSearchQuery}
                      onChange={(e) => handleSearchChange(e.target.value)}
                      className="w-full bg-[#12121c] border border-gray-800 focus:border-blue-500/50 rounded-xl py-3 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none transition-all"
                    />
                  </div>

                  {/* Search results suggestion column */}
                  {localSearchResults.length > 0 && (
                    <div className="bg-[#12121c] border border-gray-800 rounded-2xl p-2.5 max-h-[30vh] overflow-y-auto space-y-1 shadow-inner">
                      {localSearchResults.map(food => (
                        <button
                          key={food.name}
                          type="button"
                          onClick={() => handleSelectLocalResult(food)}
                          className="w-full text-left p-3 hover:bg-blue-600/10 rounded-xl transition-colors flex justify-between items-center cursor-pointer"
                        >
                          <div>
                            <span className="text-xs font-semibold text-white block">{food.name}</span>
                            <span className="text-[10px] text-gray-400 block mt-0.5">Portion: {food.serving} · P:{food.protein}g C:{food.carbs}g F:{food.fat}g</span>
                          </div>
                          <span className="text-xs text-blue-400 font-mono font-bold">{food.calories} kcal</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {foodSearchQuery.trim() !== "" && localSearchResults.length === 0 && (
                    <div className="bg-[#07070f] border border-gray-800 p-5 rounded-2xl text-center shadow-md">
                      <span className="text-xs text-gray-400 italic">No matches in 200 local database items. Let's run a web search fallback.</span>
                      <button
                        type="button"
                        onClick={async () => {
                          setPhotoProcessingState('looking_up');
                          let res: any = null;
                          try {
                            res = await lookupUSDA(foodSearchQuery);
                            if (res) {
                              setDetectedFoodResult({ ...res, source: 'USDA', mlConfidence: 100 });
                              setPortionAmount(100);
                              setPhotoProcessingState('success');
                              return;
                            }
                          } catch (e) {}

                          try {
                            res = await lookupOpenFoodFacts(foodSearchQuery);
                            if (res) {
                              setDetectedFoodResult({ ...res, source: 'Open Food Facts', mlConfidence: 100 });
                              setPortionAmount(100);
                              setPhotoProcessingState('success');
                              return;
                            }
                          } catch (e) {}

                          setPhotoProcessingState('error');
                          setPhotoProcessingError(`Could not find nutrition results for "${foodSearchQuery}" on USDA or OFF.`);
                        }}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 mt-3 py-2.5 rounded-xl text-xs font-semibold transition-all text-center block cursor-pointer shadow-md text-white"
                      >
                        Lookup "{foodSearchQuery}" online (USDA FDC)
                      </button>
                    </div>
                  )}

                  {/* Standard Popular Chips suggestions shortcut */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Common Search Queries</span>
                    <div className="flex flex-wrap gap-2">
                      {["Chicken Breast", "Eggs (whole)", "Rice", "Avocado", "Salmon", "Pizza Margherita", "Salad", "Broccoli", "Oatmeal", "Greek Yogurt"].map(term => (
                        <button
                          key={term}
                          type="button"
                          onClick={() => {
                            setFoodSearchQuery(term);
                            handleSearchChange(term);
                          }}
                          className="bg-[#12121c] border border-gray-800 hover:border-gray-700 text-gray-400 hover:text-white px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* CONFIRMATION / PORTIONS ADJUSTMENT VIEW CARD */}
              {(detectedFoodResult || selectedFoodItem) && (
                <div className="space-y-5">
                  {(() => {
                    const baseItem = detectedFoodResult || selectedFoodItem!;
                    const src = detectedFoodResult ? (detectedFoodResult.source || 'Local DB') : selectedFoodSource;
                    const matchPercent = detectedFoodResult ? (detectedFoodResult.mlConfidence || 90) : selectedFoodConfidence;

                    // Portion modifiers multipliers
                    const mult = portionAmount / 100;
                    const activeCals = Math.round(baseItem.calories * mult);
                    const activeProt = Math.round(baseItem.protein * mult * 10) / 10;
                    const activeCarb = Math.round(baseItem.carbs * mult * 10) / 10;
                    const activeFats = Math.round(baseItem.fat * mult * 10) / 10;
                    const activeFiber = Math.round((baseItem.fiber || 0) * mult * 10) / 10;
                    const activeSugar = Math.round((baseItem.sugar || 0) * mult * 10) / 10;
                    const activeSodium = Math.round((baseItem.sodium || 0) * mult);

                    return (
                      <div className="space-y-5">
                         {/* Food description box with source pills */}
                        <div className="bg-[#12121c] border border-gray-800 p-4.5 rounded-2xl shadow-md">
                          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                            <span className="text-[9px] font-mono uppercase tracking-widest font-semibold text-blue-400">Identified Food Match</span>
                            
                            {/* Color-coded Source Pill Badge */}
                            <span className={`text-[8px] font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                              src === 'USDA' 
                                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                                : src === 'Open Food Facts'
                                ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                                : 'bg-slate-500/15 text-slate-400 border border-slate-500/30'
                            }`}>
                              Source: {src}
                            </span>

                            {matchPercent < 100 && (
                              <span className="text-[8px] text-blue-400 font-mono bg-blue-500/10 px-1 py-0.5 rounded">
                                Confidence: {matchPercent}%
                              </span>
                            )}
                          </div>

                          <h4 className="text-base font-display font-bold text-white capitalize leading-snug">{baseItem.name}</h4>
                          <span className="text-[10px] text-gray-500 block font-mono mt-1">Calculated per {portionAmount}g (Baseline 100g serving)</span>
                        </div>

                        {/* Portion adjustment scale controls */}
                        <div className="bg-[#12121c] border border-gray-800 p-4.5 rounded-2xl shadow-md">
                          <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block mb-3 text-center">Adjust Portion Size (grams)</span>
                          
                          <div className="flex items-center justify-between max-w-[280px] mx-auto gap-4">
                            <button
                              type="button"
                              onClick={() => setPortionAmount(p => Math.max(10, p - 50))}
                              className="w-12 h-12 rounded-xl bg-[#07070f] border border-gray-800 hover:bg-[#12121c] flex items-center justify-center transition-colors shadow-inner cursor-pointer"
                            >
                              <Minus className="w-5 h-5 text-gray-300" />
                            </button>

                            <div className="flex items-baseline gap-1 select-none">
                              <input 
                                type="number" 
                                value={portionAmount}
                                onChange={(e) => setPortionAmount(Math.max(1, parseInt(e.target.value) || 0))}
                                className="w-20 bg-transparent text-center font-display font-bold text-2xl text-white border-b border-blue-500/30 focus:border-blue-500 focus:outline-none focus:ring-0 py-0.5"
                              />
                              <span className="text-sm text-blue-400 font-semibold">g</span>
                            </div>

                            <button
                              type="button"
                              onClick={() => setPortionAmount(p => Math.min(1500, p + 50))}
                              className="w-12 h-12 rounded-xl bg-[#07070f] border border-gray-800 hover:bg-[#12121c] flex items-center justify-center transition-colors shadow-inner cursor-pointer"
                            >
                              <Plus className="w-5 h-5 text-gray-300" />
                            </button>
                          </div>
                        </div>

                        {/* Nutrition dynamic values breakdown */}
                        <div className="bg-[#12121c] border border-gray-800 p-5 rounded-3xl space-y-4 shadow-xl">
                          
                          {/* Energy calories */}
                          <div className="flex justify-between items-baseline border-b border-gray-800/60 pb-3">
                            <span className="text-xs text-gray-400">Calorific Energy</span>
                            <span className="text-2xl font-display font-bold text-blue-400 font-mono">{activeCals} <span className="text-xs font-sans text-gray-400">kcal</span></span>
                          </div>

                          {/* Core macros table */}
                          <div className="grid grid-cols-3 gap-4 border-b border-gray-800/60 pb-4">
                            <div className="bg-[#07070f] p-3 rounded-xl border border-gray-850 text-center">
                              <span className="text-[10px] text-gray-500 block uppercase font-mono">Protein</span>
                              <span className="text-base font-bold text-blue-400 font-mono mt-0.5 block">{activeProt}g</span>
                            </div>
                            <div className="bg-[#07070f] p-3 rounded-xl border border-gray-850 text-center">
                              <span className="text-[10px] text-gray-500 block uppercase font-mono">Carbs</span>
                              <span className="text-base font-bold text-purple-400 font-mono mt-0.5 block">{activeCarb}g</span>
                            </div>
                            <div className="bg-[#07070f] p-3 rounded-xl border border-gray-850 text-center">
                              <span className="text-[10px] text-gray-500 block uppercase font-mono">Lipid Fats</span>
                              <span className="text-base font-bold text-orange-400 font-mono mt-0.5 block">{activeFats}g</span>
                            </div>
                          </div>

                          {/* Micros list */}
                          <div className="grid grid-cols-3 gap-4 text-center">
                            <div>
                              <span className="text-[9px] text-gray-500 font-mono uppercase block">Fiber</span>
                              <span className="text-xs text-slate-300 font-semibold block mt-0.5">{activeFiber}g</span>
                            </div>
                            <div>
                              <span className="text-[9px] text-gray-500 font-mono uppercase block">Sugars</span>
                              <span className="text-xs text-slate-300 font-semibold block mt-0.5">{activeSugar}g</span>
                            </div>
                            <div>
                              <span className="text-[9px] text-gray-500 font-mono uppercase block">Sodium</span>
                              <span className="text-xs text-slate-300 font-semibold block mt-0.5">{activeSodium}mg</span>
                            </div>
                          </div>

                        </div>

                        {/* Confirmation actions row */}
                        <div className="grid grid-cols-2 gap-3.5 pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedFoodItem(null);
                              setDetectedFoodResult(null);
                              setCapturedImagePreview(null);
                              setPhotoProcessingState('idle');
                            }}
                            className="bg-[#12121c] hover:bg-[#1b1b2a] border border-gray-800 text-gray-300 font-semibold py-3.5 rounded-xl text-xs transition-all text-center cursor-pointer"
                          >
                            Cancel / Clear Selection
                          </button>

                          <button
                            type="button"
                            onClick={handleConfirmLogFood}
                            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-semibold py-3.5 rounded-xl text-xs shadow-[0_4px_15px_rgba(59,130,246,0.25)] transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Check className="w-4 h-4" /> Log {portionAmount}g to {activeLogMealType}
                          </button>
                        </div>

                      </div>
                    );
                  })()}
                </div>
              )}

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- MODAL 2: LOG WORKOUT CALORIES OVERLAY --- */}
      <AnimatePresence>
        {showWorkoutModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#000000]/80 z-50 backdrop-blur-sm flex items-center justify-center px-6"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0c0c14] border border-gray-800 p-6 rounded-3xl w-full max-w-sm text-center space-y-4 shadow-2xl"
            >
              <div>
                <h3 className="text-base font-display font-bold text-white">Log Burned Calories</h3>
                <p className="text-[11px] text-gray-400 mt-1">This dynamically adds to daily limits so you eat for physical output.</p>
              </div>

              <form onSubmit={handleAddWorkout} className="space-y-4 text-left">
                <div>
                  <label className="block text-[10px] font-mono text-gray-500 uppercase mb-1.5 ml-1">Workout Activity Name</label>
                  <input 
                    type="text"
                    placeholder="e.g. Rowing, Jogging, Cycling..."
                    value={customWorkoutName}
                    onChange={(e) => setCustomWorkoutName(e.target.value)}
                    className="w-full bg-[#12121c] border border-gray-800 rounded-xl py-2.5 px-3.5 text-xs focus:outline-none focus:border-blue-500/50 transition-colors text-white placeholder-gray-600"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono text-gray-500 uppercase mb-1.5 ml-1">Calories Burned (kcal)</label>
                  <input 
                    type="number"
                    required
                    placeholder="e.g. 350"
                    value={customWorkoutCals}
                    onChange={(e) => setCustomWorkoutCals(e.target.value)}
                    className="w-full bg-[#12121c] border border-gray-800 rounded-xl py-2.5 px-3.5 text-xs focus:outline-none focus:border-blue-500/50 transition-colors text-white placeholder-gray-600"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowWorkoutModal(false)}
                    className="bg-[#12121c] border border-gray-800 text-gray-400 hover:text-white font-semibold py-2.5 rounded-xl text-xs transition-colors text-center cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-semibold py-2.5 rounded-xl text-xs transition-all text-center cursor-pointer shadow-md"
                  >
                    Confirm Workout
                  </button>
                </div>
              </form>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
